from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,cv2,subprocess,json,math
p=Path(__file__).parent
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def tx(d,xy,t,size=32,color='#e9f1ee'):
 d.multiline_text(xy,t,font=ImageFont.truetype(font,size),fill=color,anchor='mm',align='center',spacing=10)
models=[Image.open(p/f'model_{i:02}.png').convert('RGBA') for i in range(16)]
def arrow(d,a,b,c):
 d.line((*a,*b),fill=c,width=5);ang=math.atan2(b[1]-a[1],b[0]-a[0]);d.polygon([b,(b[0]-19*math.cos(ang-.5),b[1]-19*math.sin(ang-.5)),(b[0]-19*math.cos(ang+.5),b[1]-19*math.sin(ang+.5))],fill=c)
def panel(t):
 im=Image.new('RGB',(1080,1420),'#091b25');d=ImageDraw.Draw(im)
 tx(d,(540,85),'ВНУТРИ ПЕРЕВЁРНУТОГО БУКСИРА',40)
 tx(d,(540,155),'Условный объёмный разрез отсека',27,'#a4bec9')
 # Slow explanatory reveal and local ripple motion; no shaky camera.
 u=(t*4)%16;i=int(u);model=Image.blend(models[i],models[(i+1)%16],u-i)
 scale=1+.06*min(t/5,1);model=model.resize((round(1000*scale),round(900*scale)),Image.Resampling.LANCZOS)
 im.paste(model,((1080-model.width)//2,310-(model.height-900)//2),model)
 d=ImageDraw.Draw(im);stage=min(int(t/2.5),2)
 titles=['1  ВОЗДУХ ОСТАЛСЯ НАД ВОДОЙ','2  ОПОРА ПОМОГАЛА ДЕРЖАТЬСЯ ВЫШЕ','3  ВЫХОД ИЗ ОТСЕКА ЗАТОПЛЕН']
 tx(d,(540,235),titles[stage],30,'#ffcf83')
 if stage==0:
  tx(d,(840,390),'ВОЗДУХ',28,'#ffcf83');arrow(d,(820,420),(700,540),'#ffcf83')
 elif stage==1:
  tx(d,(200,500),'ГОЛОВА\nНАД ВОДОЙ',25,'#ffcf83');arrow(d,(270,530),(510,630),'#ffcf83')
  tx(d,(845,1040),'ОПОРА',26,'#ffcf83');arrow(d,(800,1008),(680,895),'#ffcf83')
 else:
  tx(d,(185,580),'ПРОХОД\nПОД ВОДОЙ',25,'#80d6e8');arrow(d,(230,620),(330,785),'#80d6e8')
  # A moving indicator follows the submerged route; this is a diagram, not a recorded action.
  q=(t%1.7)/1.7;x=330-180*q;y=785+100*q;d.ellipse((x-7,y-7,x+7,y+7),fill='#85dcea')
 tx(d,(540,1260),'ГЛУБИНА ОКОЛО 30 МЕТРОВ',34,'#ffcf83')
 tx(d,(540,1330),'Положение и размеры показаны условно',23,'#9bb2bb')
 return np.asarray(im)
words=json.loads((p/'boundaries.json').read_text())
def at(w):return next(x['offset']/1e7 for x in words if x['text'].lower().strip('.,:')==w.lower())
a=at('воздушном');b=at('Прошли');(p/'animation_timing.json').write_text(json.dumps({'start':a,'end':b,'stages':['air pocket','raised seated position','flooded passage']}))
Image.fromarray(panel(4)).save(p/'diagram_review.png')
cap=cv2.VideoCapture(str(p/'SNG_005_Okene_BASE_V4.mp4'));duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p/'SNG_005_Okene_BASE_V4.mp4')]))
f=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-i',str(p/'SNG_005_Okene_BASE_V4.mp4'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','copy','-t',str(duration),'-movflags','+faststart',str(p/'SNG_005_Okene_PREVIEW_V4.mp4')],stdin=subprocess.PIPE);n=0
while True:
 ok,fr=cap.read()
 if not ok:break
 fr=cv2.cvtColor(fr,cv2.COLOR_BGR2RGB);t=n/30
 if a<=t<b:fr[:1420]=panel(t-a)
 f.stdin.write(fr.tobytes());n+=1
cap.release();f.stdin.close();assert f.wait()==0;print('Rendered',n,'frames')
