import bpy,math
from mathutils import Vector
from pathlib import Path
p=Path(__file__).parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=24;sc.cycles.use_denoising=False
sc.render.resolution_x=1000;sc.render.resolution_y=900;sc.render.resolution_percentage=100
sc.world.color=(.12,.16,.20);sc.render.image_settings.file_format='PNG';sc.render.film_transparent=True
sc.view_settings.view_transform='AgX'
def mat(name,col,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*col,1);bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=.5;return m
steel=mat('Weathered steel',(.16,.24,.27),.65);edge=mat('Ribs',(.32,.39,.40),.7);rust=mat('Rust',(.29,.13,.065));wood=mat('Improvised raised support',(.26,.18,.10));cloth=mat('Mattress',(.48,.47,.35));skin=mat('Skin',(.22,.105,.055));pants=mat('Dark shorts',(.035,.06,.075));hair=mat('Hair',(.012,.008,.006));water=mat('Water',(.015,.15,.20),.4)
bs=water.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=.22
noise=water.node_tree.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=5;bump=water.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.24;bump.inputs['Distance'].default_value=.12;water.node_tree.links.new(noise.outputs['Fac'],bump.inputs['Height']);water.node_tree.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
def box(name,loc,size,m):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);mod=o.modifiers.new('Soft edges','BEVEL');mod.width=.025;mod.segments=2;o.modifiers.new('Normals','WEIGHTED_NORMAL');return o
def ball(name,loc,size,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=loc);o=bpy.context.object;o.name=name;o.scale=size;o.data.materials.append(m);bpy.ops.object.shade_smooth();return o
def rod(name,a,b,r,m):
 d=Vector(b)-Vector(a);bpy.ops.mesh.primitive_cylinder_add(vertices=16,radius=r,depth=d.length,location=(Vector(a)+Vector(b))/2);o=bpy.context.object;o.name=name;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();o.data.materials.append(m);o.modifiers.new('Normals','WEIGHTED_NORMAL');return o
box('Compartment floor',(0,0,-.08),(4.8,3.3,.16),steel)
box('Rear bulkhead',(0,1.6,1.6),(4.8,.12,3.2),steel)
box('Side bulkhead',(2.35,0,1.6),(.12,3.3,3.2),steel)
for x in [-2,-1,0,1,2]:
 box('Structural rib',(x,1.48,1.6),(.08,.14,3.1),edge)
 for z in [.3,1.4,2.7]:ball('Rivet',(x,1.39,z),(.035,.025,.035),rust)
for z in [1.8,2.65]:rod('Pipe',(-2.2,1.30,z),(2.0,1.30,z),.045,edge)
# Roof beams, front and roof removed to make the air pocket legible.
for x in [-2.15,1.9]:box('Ceiling beam',(x,.1,3.12),(.15,3.0,.16),edge)
box('Rear roof edge',(0,1.5,3.12),(4.8,.2,.16),edge)
# Submerged doorway clearly visible in rear wall, under water level.
box('Flooded doorway',(-1.5,1.51,.6),(.72,.15,1.12),hair)
# Support is illustrative, not a documentary claim of dimensions.
box('Raised platform',(.2,.0,1.12),(1.75,1.2,.15),wood);box('Mattress',(.2,0,1.24),(1.7,1.16,.15),cloth)
for x in [-.5,.9]:
 for y in [-.45,.45]:box('Support leg',(x,y,.57),(.12,.12,1.14),wood)
# Seated adult, knees bent and feet lower, head well above the waterline.
ball('Pelvis',(.12,0,1.49),(.29,.23,.23),pants)
ball('Torso',(.12,.08,1.91),(.29,.20,.49),skin)
rod('Neck',(.12,.06,2.28),(.12,.02,2.40),.105,skin)
ball('Head',(.12,-.015,2.57),(.19,.17,.24),skin);ball('Hair',(.12,.015,2.70),(.19,.16,.12),hair)
ball('Nose',(.12,-.184,2.57),(.04,.055,.055),skin)
for x in [-.01,.25]:
 rod('Thigh',(x,-.04,1.49),(x,-.62,1.57),.135,pants)
 ball('Knee',(x,-.63,1.55),(.12,.12,.12),skin)
 rod('Calf',(x,-.62,1.54),(x,-.75,.95),.08,skin)
 ball('Foot',(x,-.88,.91),(.09,.21,.08),skin)
for x,elbow in [(-.17,(-.25,-.30,1.87)),(.41,(.50,-.29,1.86))]:
 rod('Upper arm',(x,.05,2.17),elbow,.085,skin)
 rod('Forearm',elbow,(x,-.58,1.69),.065,skin)
 ball('Hand',(x,-.60,1.66),(.075,.11,.045),skin)
box('Water volume',(0,-.08,.60),(4.65,3.05,1.20),water)
bpy.ops.mesh.primitive_plane_add(size=1,location=(0,-.08,1.225));surface=bpy.context.object;surface.name='Water surface';surface.scale=(4.65,3.05,1);surface.data.materials.append(water)
# Camera fixed: animation comes from water and light.
bpy.ops.object.camera_add(location=(5,-8,5.5));cam=bpy.context.object;cam.rotation_euler=(Vector((0,.1,1.6))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=6.4;sc.camera=cam
for loc,power,col,size in [((0,-4,6),1000,(.62,.81,1),5),((-3,0,4),800,(1,.7,.36),4),((3,3,6),1100,(.4,.7,1),3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.color=col;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
# Sixteen phases for a seamless, visible ripple/light cycle.
bpy.ops.wm.save_as_mainfile(filepath=str(p/'Okene_cutaway.blend'))
for i in range(16):
 noise.inputs['Scale'].default_value=5+.35*math.sin(i/16*math.tau)
 surface.location.z=1.225+.015*math.sin(i/16*math.tau)
 sc.render.filepath=str(p/f'model_{i:02}.png');bpy.ops.render.render(write_still=True)