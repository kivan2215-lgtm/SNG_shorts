from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
import numpy as np,subprocess,json,math,wave,re,shutil
p=Path(__file__).parent;voice=p/'v0.mp3'
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(voice),'-af','silencedetect=noise=-40dB:d=0.55','-f','null','-'],capture_output=True,text=True)
a=list(map(float,re.findall('silence_start: ([0-9.]+)',r.stderr)));b=list(map(float,re.findall('silence_end: ([0-9.]+)',r.stderr)));cuts=[(x+.22,y-.22) for x,y in zip(a,b) if y-x>.65]
subprocess.run(['ffmpeg','-y','-v','error','-i',str(voice),'-ar','48000','-ac','1',str(p/'original.wav')],check=True)
with wave.open(str(p/'original.wav')) as w:v=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2')
parts=[];last=0
for x,y in cuts:parts.append(v[last:round(x*48000)]);last=round(y*48000)
parts.append(v[last:]);v=np.concatenate(parts)
with wave.open(str(p/'voice.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes(v.tobytes())
def remap(t):return t-sum(max(0,min(t,y)-x) for x,y in cuts if t>x)
words=json.loads((p/'boundaries.json').read_text());
for w in words:w['offset']=round(remap(w['offset']/1e7)*1e7)
duration=math.ceil(len(v)/1600)/30
(p/'edited_boundaries.json').write_text(json.dumps(words,ensure_ascii=False))
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def txt(d,xy,s,n=45,color='#f5f0e6',width=940):
 while max(ImageFont.truetype(font,n).getlength(x) for x in s.split('\n'))>width:n-=1
 d.multiline_text(xy,s,font=ImageFont.truetype(font,n),anchor='mm',align='center',fill=color,spacing=15)
def canvas(title):
 im=Image.new('RGB',(1080,1920),'#0b2029');d=ImageDraw.Draw(im);txt(d,(540,140),title,47);return im,d
grid=Image.open(p/'recon.png').convert('RGB');W,H=grid.size
panels=[grid.crop((c*W//3+4,r*H//3+4,(c+1)*W//3-4,(r+1)*H//3-4)) for r in range(3) for c in range(3)]
def scene(i,title):
 im,d=canvas(title);pic=ImageOps.fit(panels[i],(1080,1080),Image.Resampling.LANCZOS);im.paste(pic,(0,255));txt(d,(830,290),'ИЛЛЮСТРАЦИЯ',20,'#d4d4d1',340);return im
def chart(stage):
 im,d=canvas('ЧТО ПРОИЗОШЛО В ОЗЕРЕ')
 d.rounded_rectangle((100,330,980,1330),radius=40,fill='#163947',outline='#6f98a3',width=4)
 d.polygon([(130,700),(360,610),(590,720),(940,540),(940,1090),(130,1090)],fill='#315c49')
 d.polygon([(200,720),(850,720),(850,1150),(200,1150)],fill='#155d79')
 d.line((200,720,850,720),fill='#84cce0',width=6)
 txt(d,(530,390),'1  ГАЗ НАКАПЛИВАЛСЯ В ГЛУБИНЕ',30,'#ffd28a')
 for j in range(15):
  x=290+(j%5)*110;y=1010+(j//5)*30-70*stage
  if y>755:d.ellipse((x,y,x+13,y+13),fill='#b6e1e9')
 if stage>=1:
  txt(d,(540,470),'2  ВОДА ВЫПУСТИЛА CO₂',30,'#ffd28a');d.line((530,870,530,670),fill='#ffd28a',width=8);d.polygon([(530,645),(510,680),(550,680)],fill='#ffd28a')
 if stage>=2:
  txt(d,(540,1190),'3  НЕВИДИМЫЙ ГАЗ СТЕКАЛ В ДОЛИНЫ',29,'#ffd28a')
 txt(d,(540,1360),'ПОЯСНЯЮЩАЯ СХЕМА • НЕ ТОЧНАЯ КАРТА',22,'#aac0c9');return im
scenes=[(0,scene(0,'УТРО ПОСЛЕ КАТАСТРОФЫ')),(3,scene(1,'ДОМА СТОЯЛИ ЦЕЛЫМИ')),(6,scene(8,'НИ ПОЖАРА, НИ СЛЕДОВ НАПАДЕНИЯ')),(10,scene(2,'УЦЕЛЕВШАЯ РАСТИТЕЛЬНОСТЬ')),(14,scene(5,'КАМЕРУН • АВГУСТ 1986')),(18,scene(4,'ГРОХОТ СО СТОРОНЫ ОЗЕРА')),(23,scene(0,'ЛЮДИ ТЕРЯЛИ СОЗНАНИЕ')),(27,scene(8,'ПОСТРАДАЛО НЕСКОЛЬКО ПОСЕЛЕНИЙ')),(32,scene(2,'БОЛЕЕ 1700 ПОГИБШИХ')),(37,scene(6,'ПРИЧИНУ НАШЛИ В ОЗЕРЕ')),(41,chart(0)),(46,chart(1)),(52,chart(2)),(57,scene(7,'ОЗЕРО НИОС'))]
# Shift last cards to exact duration if needed, keep reveal near 40 seconds.
scenes=[(min(t,duration-.6),im) for t,im in scenes if t<duration-.5];scenes.sort(key=lambda x:x[0])
manifest=[]
for i,(t,im) in enumerate(scenes):
 end=scenes[i+1][0] if i+1<len(scenes) else duration;f=p/f'card{i:02}.png';im.save(f);manifest.append(f"file '{f}'\noption framerate 30\nduration {end-t:.6f}\n")
manifest.append(f"file '{f}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest))
header=(p.parent/'short_004_juliane_v2/subtitles.ass').read_text().split('Dialogue:')[0]
def ts(t):return f'{int(t//3600)}:{int(t//60)%60:02}:{t%60:05.2f}'
lines=[]
for i in range(0,len(words),4):
 g=words[i:i+4];a=g[0]['offset']/1e7;b=words[i+4]['offset']/1e7 if i+4<len(words) else duration
 label=' '.join(x['text'].upper() for x in g[:2])+'\\N'+' '.join(x['text'].upper() for x in g[2:]);lines.append(f'Dialogue: 0,{ts(a)},{ts(b)},S,,0,0,0,,{{\\pos(500,1510)}}{label}\n')
(p/'subtitles.ass').write_text(header+''.join(lines))
# Quiet original minor-key ambience, starting in silence and fading out in final second.
t=np.arange(len(v))/48000;music=.005*np.sin(2*np.pi*47*t)+.003*np.sin(2*np.pi*70.5*t);music*=np.minimum(np.maximum((t-2)/3,0),1)*np.minimum(np.maximum((duration-t)/1,0),1)
mix=np.clip(v.astype(float)/32768+music,-1,1)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes((mix*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(p/'mix.wav'),'-vf',f'fps=30,ass={p/"subtitles.ass"}','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-t',str(duration),'-movflags','+faststart',str(p/'SNG_006_Nyos_PREVIEW.mp4')],check=True)
print('DURATION',duration,'SCENES',len(scenes))
