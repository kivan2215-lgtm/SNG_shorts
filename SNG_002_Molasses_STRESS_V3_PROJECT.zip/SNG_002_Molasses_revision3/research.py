import urllib.request,json,urllib.parse
from pathlib import Path
p=Path(__file__).parent
def api(args):
 u='https://commons.wikimedia.org/w/api.php?'+urllib.parse.urlencode(dict(action='query',format='json',**args))
 return json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'SNGShorts documentary research'}),timeout=25))
x=api({'list':'categorymembers','cmtitle':'Category:Great_Molasses_Flood','cmlimit':100})
(p/'category.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
print(json.dumps(x,ensure_ascii=False)[:10000])
