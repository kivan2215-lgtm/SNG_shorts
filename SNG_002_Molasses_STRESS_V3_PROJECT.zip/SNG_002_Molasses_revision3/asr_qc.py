import sherpa_onnx,numpy as np,subprocess,json
from pathlib import Path
p=Path(__file__).parent;m=Path('/workspace/.sng-shorts/models/sherpa-onnx-whisper-base')
r=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(m/'base-encoder.int8.onnx'),decoder=str(m/'base-decoder.int8.onnx'),tokens=str(m/'base-tokens.txt'),language='ru',task='transcribe',num_threads=4)
a=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p/'mix.wav'),'-ar','16000','-ac','1','-f','f32le','-']),dtype=np.float32)
out=[]
for start in range(0,len(a),25*16000):
 s=r.create_stream();s.accept_waveform(16000,a[start:start+25*16000]);r.decode_stream(s);out.append({'start':start/16000,'text':s.result.text});print(out[-1],flush=True)
(p/'asr_check.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
