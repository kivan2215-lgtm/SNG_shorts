import asyncio,os,json
from pathlib import Path
import edge_tts,edge_tts.communicate as ec
p=Path(__file__).parent
text='''Этот бак протекал. Его просто… покрасили.
Январь тысяча девятьсот девятнадцатого года. У набережной Бо́стона — огромный стальной бак. В нём па́тока: густой сладкий сироп. Высота бака — пятнадцать метров, диаметр — двадцать семь.
Бак протекал. Па́тока сочилась из швов. Но резервуар покрасили в коричневый цвет. Проблема исчезла? Только с виду.
Пятнадцатого января бак разорвало. Почти девять миллионов литров па́токи хлынули по улицам.
Поток разрушал здания и повредил опоры надземной железной дороги. Улицы покрыла густая липкая масса.
Погиб двадцать один человек. Около ста пятидесяти получили травмы.
Но самое страшное… Об утечках знали ещё до катастрофы.
Позже компанию признали ответственной за катастрофу. Краска не укрепила металл. Она лишь спрятала предупреждение.
Его покрасили в цвет па́токи. Чтобы потёков не было видно.'''
(p/'tts_script.txt').write_text(text)
ca=os.environ.get('SSL_CERT_FILE') or os.environ.get('CODEX_PROXY_CERT')
import ssl
original_context=ssl.create_default_context
def trusted_context(*a,**kw):
 ctx=original_context(*a,**kw)
 if ca:ctx.load_verify_locations(cafile=ca)
 return ctx
ssl.create_default_context=trusted_context
import re
lines=[text.replace('\n',' ')]
async def main():
 import subprocess
 boundaries=[];offset=0
 for i,line in enumerate(lines):
  import unicodedata
  line=unicodedata.normalize('NFC',line).replace('…',',').replace('—',',')
  for attempt in range(6):
   try:
    c=edge_tts.Communicate(line+'.','ru-RU-DmitryNeural',rate='+8%',boundary='WordBoundary',proxy=os.environ.get('HTTPS_PROXY'))
    b=[];out=p/f'v{i}.mp3'
    with out.open('wb') as f:
     async for m in c.stream():
      if m['type']=='audio':f.write(m['data'])
      else:b.append(m)
    for w in b:w['offset']+=round(offset*1e7)
    boundaries.extend(b)
    dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(out)]))
    offset+=dur
    print(i,dur,flush=True);break
   except edge_tts.exceptions.NoAudioReceived:
    if attempt==5:raise
    await asyncio.sleep(2)
 (p/'boundaries.json').write_text(json.dumps(boundaries,ensure_ascii=False))
 (p/'voice_concat.txt').write_text(''.join(f"file '{p/f'v{i}.mp3'}'\n" for i in range(len(lines))))
asyncio.run(main())
