from pathlib import Path
import urllib.request,urllib.parse,hashlib,re,html,concurrent.futures,json
from PIL import Image
p=Path(__file__).parent
base='Boston_Elevated_Railway_after_the_Molasses_Flood,_January_1919,_from_the_City_of_Boston_Archives_-_9800-018-'
names=[base+n+'.jpg' for n in ['051','052']]
def get(name):
 digest=hashlib.md5(name.encode()).hexdigest();url=f'https://upload.wikimedia.org/wikipedia/commons/{digest[0]}/{digest[:2]}/'+urllib.parse.quote(name)
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as r:(p/name).write_bytes(r.read())
  page='https://commons.wikimedia.org/wiki/File:'+urllib.parse.quote(name)+'?uselang=en'
  s=urllib.request.urlopen(urllib.request.Request(page,headers={'User-Agent':'Mozilla/5.0'}),timeout=20).read().decode();(p/(name+'.html')).write_text(s)
  text=html.unescape(re.sub('<[^>]+>',' ',s));text=re.sub(r'\s+',' ',text)
  i=text.find('Licensing');print(name,Image.open(p/name).size,text[i:i+1800],flush=True)
  return dict(file=name,url=url,page=page,width=Image.open(p/name).width,height=Image.open(p/name).height,rights_excerpt=text[i:i+2400])
 except Exception as e:print(name,e,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:items=list(pool.map(get,names))
(p/'archive_manifest_extra.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
