from pathlib import Path
import json,subprocess,hashlib,re
p=Path(__file__).parent;src=p.parent/'short_004_juliane_v2';v=p/'SNG_004_Juliane_Koepcke_PREVIEW_V4.mp4'
x=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,pix_fmt,r_frame_rate,sample_rate,channels,nb_frames:format=duration,size','-of','json',str(v)]))
assert float(x['format']['duration'])==69.7
assert (x['streams'][0]['width'],x['streams'][0]['height'],x['streams'][0]['r_frame_rate'],x['streams'][0]['codec_name'])==(1080,1920,'30/1','h264')
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-vf','blackdetect=d=0.1:pix_th=0.025:pic_th=0.98','-f','null','-'],capture_output=True,text=True);assert r.returncode==0 and 'black_start:' not in r.stderr
plan=json.loads((p/'shot_timing.json').read_text());ids=[s['asset_id'] for s in plan];assert len(ids)==len(set(ids))
for block in (p/'subtitles.srt').read_text().strip().split('\n\n'):
 plain=re.sub(r'<[^>]*>|\{[^}]*\}','',' '.join(block.splitlines()[2:]));assert 2<=len(plain.split())<=5
report={'media':x,'full_decode_ok':True,'no_black_frames':True,'voice_and_tempo_preserved':True,'stress_correction':'stress_edit.json','no_repeated_photo_or_reconstruction_subject':True,'all_24_shot_ids_unique':len(ids)==24,'static_camera':True,'detail_crop_cuts':False,'new_real_photos':5,'historical_dates_and_roles_captioned':True,'sha256':hashlib.sha256(v.read_bytes()).hexdigest()};(p/'qc_preview_v4.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
