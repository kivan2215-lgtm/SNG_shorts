from pathlib import Path
import wave,json,subprocess
import numpy as np
p=Path(__file__).parent;src=p.parent/'short_004_juliane_v2';sr=48000
with wave.open(str(src/'mix.wav')) as w:a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(float)/32768
# Native word is acoustically stressed on first syllable; shift actual acoustic prominence to final /i/.
x0,x1,y0,y1=[round(t*sr) for t in (45.831,45.944,46.043,46.133)];delta=round(.025*sr)
def edit(x,n,pitch,gain):
 pad=round(.15*sr);tempo=len(x)/n;raw=subprocess.check_output(['ffmpeg','-v','error','-f','f32le','-ar',str(sr),'-ac','1','-i','pipe:0','-af',f'rubberband=tempo={tempo}:pitch={pitch}:formant=preserved','-f','f32le','pipe:1'],input=np.pad(x,(pad,pad)).astype(np.float32).tobytes());z=np.frombuffer(raw,dtype=np.float32);i=round(pad/tempo);z=z[i:i+n].astype(float)*gain;z=np.pad(z,(0,max(0,n-len(z))))
 r=round(.006*sr);alpha=np.linspace(0,1,r);z[:r]=x[:r]*(1-alpha)+z[:r]*alpha;z[-r:]=z[-r:]*(1-alpha)+x[-r:]*alpha
 return z
first=edit(a[x0:x1],x1-x0-delta,.78,.70);last=edit(a[y0:y1],y1-y0+delta,1.22,1.15)
b=np.concatenate([a[:x0],first,a[x1:y0],last,a[y1:]])
assert len(b)==len(a) and np.array_equal(b[:x0],a[:x0]) and np.array_equal(b[y1:],a[y1:]);assert max(abs(b))<.98
with wave.open(str(p/'mix_corrected.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((b*32768).astype(np.int16).tobytes())
(p/'stress_edit.json').write_text(json.dumps({'word':'реки́','context':'а у реки могут оказаться люди','actual_audio_correction':True,'method':'local vowel duration/pitch/intensity shift to final vowel','first_vowel':[x0/sr,x1/sr],'final_vowel':[y0/sr,y1/sr],'other_PCM_preserved':True,'duration_preserved':True,'к реке́':'original final-vowel prominence retained','human_review':'pending'},ensure_ascii=False,indent=2))
print('Corrected actual audio; all other samples and total length preserved')
