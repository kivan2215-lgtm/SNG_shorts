from pathlib import Path
import json,subprocess,wave,math,unicodedata,re,os
import numpy as np
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent;sr=48000
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/'v0.mp3'),'-ar',str(sr),'-ac','1','-f','s16le','-']);a=np.frombuffer(raw,dtype=np.int16)
words=json.loads((p/'boundaries.json').read_text());cuts=[]
for x,y in zip(words,words[1:]):
 end=(x['offset']+x['duration'])/1e7;start=y['offset']/1e7
 if start-end>.65:cuts.append((end+.12,start-.12))
parts=[];pos=0
for x,y in cuts:parts.append(a[pos:round(x*sr)]);pos=round(y*sr)
parts.append(a[pos:]);a=np.concatenate(parts)
for w in words:
 t=w['offset']/1e7;w['start']=t-sum(y-x for x,y in cuts if y<=t);w['end']=w['start']+w['duration']/1e7
 w['text']=unicodedata.normalize('NFC',unicodedata.normalize('NFD',w['text']).replace('\u0301',''))
duration=math.ceil((words[-1]['end']+.30)*30)/30
assert 57<=duration<=65,duration
print('Duration',duration,flush=True)
a=a[:round(duration*sr)];a=np.pad(a,(0,max(0,round(duration*sr)-len(a))))
def at(phrase):
 tokens=phrase.lower().replace('ё','е').split();norm=[w['text'].lower().replace('ё','е').strip('.,!?:;—') for w in words]
 for j in range(len(norm)-len(tokens)+1):
  if norm[j:j+len(tokens)]==tokens:return words[j]['start']
 raise ValueError(phrase)
# Original music and effects: tension before escape, restrained relief afterwards.
t=np.arange(len(a))/sr;rng=np.random.default_rng(76);escape=at('все двадцать семь')
score=(np.sin(2*np.pi*49*t)+.4*np.sin(2*np.pi*73.416*t))*.0028
pulse=(np.sin(2*np.pi*(.75*t+.008*t*t))*.5+.5)**12
score+=pulse*np.sin(2*np.pi*98*t)*.002
score[t>=escape]=(.002*np.sin(2*np.pi*146.83*t[t>=escape])+.0015*np.sin(2*np.pi*220*t[t>=escape]))
for when in [at('закрыли люк'),at('приподняли крышку')]:
 n=round(.25*sr);u=np.arange(n)/sr;fx=(rng.normal(0,1,n)*.01+np.sin(2*np.pi*95*u)*.02)*np.exp(-u*15);start=round(when*sr);score[start:start+n]+=fx
mix=np.clip(a.astype(float)/32768+score,-.95,.95)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype(np.int16).tobytes())
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def F(n):return ImageFont.truetype(font,n)
C={'bg':'#10171c','white':'#f4eee0','gold':'#ecc16e','muted':'#a8b4bb','red':'#d78566','blue':'#6aa7bd','earth':'#614f3e'}
def base(title):
 im=Image.new('RGB',(1080,1920),C['bg']);d=ImageDraw.Draw(im)
 for y in range(1920):d.line((0,y,1080,y),fill=(14+int(y/180),21+int(y/240),27+int(y/300)))
 size=54
 while max(F(size).getlength(line) for line in title.split('\n'))>960:size-=1
 d.multiline_text((540,240),title,font=F(size),fill=C['white'],anchor='mm',align='center',spacing=15)
 return im,d
def caption(d,t):d.text((540,1330),t,font=F(25),fill=C['muted'],anchor='mm')
recon=Image.open(p/'recon.png').convert('RGB');panels=[]
for row in range(3):
 for col in range(2):panels.append(recon.crop((col*512+3,row*512+3,(col+1)*512-3,(row+1)*512-3)))
archives={k:Image.open(p/f'Chowchilla_kidnapping_{k}.jpg').convert('RGB') for k in ['trailer','victims_rescued','victims_in_parade','defendants']}
archives['mugshots']=Image.open(p/'Fred_Woods,_James_Schoenfeld_and_Richard_Schoenfeld.jpg').convert('RGB')
def picture(title,source,credit):
 im,d=base(title);scale=min(1020/source.width,940/source.height);thumb=source.resize((round(source.width*scale),round(source.height*scale)),Image.Resampling.LANCZOS);x=(1080-thumb.width)//2;y=810-thumb.height//2;im.paste(thumb,(x,y));d.rectangle((x-2,y-2,x+thumb.width+1,y+thumb.height+1),outline=C['gold'],width=2);caption(d,credit);return im

def number(title,large,small):
 im,d=base(title);d.text((540,760),large,font=F(150 if len(large)<7 else 108),fill=C['gold'],anchor='mm');d.multiline_text((540,985),small,font=F(43),fill=C['white'],anchor='mm',align='center',spacing=20);return im

def section(title,mode):
 im,d=base(title)
 d.rectangle((65,480,1015,610),fill=C['earth']);d.text((540,525),'ПОВЕРХНОСТЬ КАРЬЕРА',font=F(26),fill=C['white'],anchor='mm')
 for x in range(75,1015,45):d.line((x,540,x+24,605),fill='#8d775d',width=3)
 d.rounded_rectangle((115,690,965,1170),radius=20,fill='#25323b',outline=C['blue'],width=5)
 for x in range(145,945,50):d.line((x,720,x,1140),fill='#40505b',width=2)
 d.text((315,795),'ГРУЗОВОЙ\nКУЗОВ',font=F(32),fill=C['white'],anchor='mm',align='center')
 d.rectangle((570,604,805,694),fill='#1b2125',outline=C['gold'],width=4)
 d.text((850,647),'ЛЮК',font=F(27),fill=C['gold'],anchor='mm')
 if mode in ['trap','weight']:
  d.rectangle((550,581,825,600),fill='#b4bec3')
  for x in [580,705]:
   d.rounded_rectangle((x,535,x+85,580),radius=3,fill='#1e2528',outline=C['gold'],width=2);d.rectangle((x+12,526,x+25,535),fill=C['gold'])
  d.text((540,420),'2 АККУМУЛЯТОРА + МЕТАЛЛ',font=F(32),fill=C['gold'],anchor='mm')
 if mode in ['ladder']:
  for x in [620,745]:d.line((x,625,x,1120),fill=C['gold'],width=10)
  for y in range(665,1120,65):d.line((620,y,745,y),fill=C['gold'],width=8)
 if mode in ['escape','mattress']:
  for j in range(5):d.rounded_rectangle((550,1100-j*68,850,1150-j*68),radius=16,fill='#9c8065',outline='#e3c29a',width=3)
  d.text((350,1050),'СТОПКА\nМАТРАСОВ',font=F(29),fill=C['gold'],anchor='mm',align='center')
  if mode=='escape':
   d.line((685,810,685,630),fill=C['gold'],width=10);d.polygon([(685,604),(660,647),(710,647)],fill=C['gold'])
   d.rectangle((565,575,810,595),fill=C['blue']);d.text((540,420),'ДОБРАТЬСЯ ДО ЛЮКА',font=F(35),fill=C['gold'],anchor='mm')
 caption(d,'ПОЯСНЯЮЩАЯ СХЕМА • НЕ В МАСШТАБЕ');return im

def locator():
 im,d=base('КАЛИФОРНИЯ • 1976')
 # Abstract location labels deliberately not a geographic map or reconstruction.
 d.text((540,540),'15 ИЮЛЯ',font=F(105),fill=C['gold'],anchor='mm')
 for y,text in [(800,'ШКОЛЬНЫЙ МАРШРУТ'),(1050,'КАРЬЕР У ЛИВЕРМОРА')]:
  d.rounded_rectangle((110,y-55,970,y+55),radius=20,fill='#28353e',outline=C['blue'],width=3);d.text((540,y),text,font=F(34),fill=C['white'],anchor='mm')
 d.line((540,860,540,960),fill=C['gold'],width=6);d.polygon([(540,990),(520,958),(560,958)],fill=C['gold']);caption(d,'ЧОУЧИЛЛА → ЛИВЕРМОР • СХЕМА СОБЫТИЙ');return im

def rp(i,title):return picture(title,panels[i],'РЕКОНСТРУКЦИЯ')
def ap(k,title):
 label={'trailer':'КУЗОВ ПОСЛЕ ПОХИЩЕНИЯ • АРХИВ, ИЮЛЬ 1976','victims_rescued':'СПАСЁННЫЕ • АРХИВ, ИЮЛЬ 1976','victims_in_parade':'ПАРАД ПОСЛЕ СПАСЕНИЯ • АВГУСТ 1976','defendants':'ОБВИНЯЕМЫЕ У СУДА • ОКТЯБРЬ 1976','mugshots':'ФОТО ПОЛИЦИИ • 1976'}[k]
 return picture(title,archives[k],label)
from visuals_v2 import picture,section,locator,opening
scenes=[]
def add(t,im,kind):scenes.append({'start':t,'image':im,'kind':kind})
add(0,opening('АВТОБУС НАШЛИ В КУСТАХ','НО ГДЕ ДЕТИ?'),'reconstruction')
add(at('двадцать шесть'),opening('В АВТОБУСЕ ЕХАЛИ 26 ДЕТЕЙ','ВСЕ ОНИ ИСЧЕЗЛИ'),'reconstruction')
add(at('это произошло'),locator(),'reconstruction')
add(at('автобус остановили'),rp(1,'ДОРОГУ ПЕРЕКРЫЛИ'),'reconstruction')
add(at('и пересадили'),rp(2,'ДЕТЕЙ УВЕЗЛИ В ФУРГОНАХ'),'reconstruction')
add(at('почти двенадцать'),opening('ПОЧТИ 12 ЧАСОВ В ДОРОГЕ','МАРШРУТ БЫЛ НЕИЗВЕСТЕН',2),'reconstruction')
add(at('а потом'),rp(3,'ЛЕСТНИЦА ВЕЛА ПОД ЗЕМЛЮ'),'reconstruction')
add(at('в грузовой кузов'),section('УКРЫТИЕ ПОД ЗЕМЛЁЙ','ladder'),'diagram')
add(at('похитители убрали'),ap('trailer','КУЗОВ, В КОТОРОМ ИХ ДЕРЖАЛИ'),'archive')
add(at('и закрыли люк'),section('ВЫХОД ПЕРЕКРЫЛИ','trap'),'diagram')
add(at('металлическим листом'),section('ЧТО УДЕРЖИВАЛО ЛЮК','weight'),'diagram')
add(at('двадцать семь человек'),section('В КУЗОВЕ ОСТАЛИСЬ 27 ЧЕЛОВЕК','trap'),'diagram')
add(at('в темноте'),ap('trailer','ТЕМНОТА И ДУХОТА'),'archive')
add(at('а снаружи'),section('МЕСТО ЗАТОЧЕНИЯ БЫЛО НЕИЗВЕСТНО','trap'),'diagram')
add(at('в кузове были'),ap('trailer','МАТРАСЫ, НЕМНОГО ЕДЫ И ВОДЫ'),'archive')
add(at('но со временем'),section('ПОТОЛОК НАЧАЛ ПРОГИБАТЬСЯ','roof'),'diagram')
add(at('водитель и старшие'),rp(5,'ОНИ НАЧАЛИ СКЛАДЫВАТЬ МАТРАСЫ'),'reconstruction')
add(at('друг на друга'),section('КАК ДОБРАЛИСЬ ДО ЛЮКА','mattress'),'diagram')
add(at('приподняли крышку'),section('КРЫШКУ НУЖНО УДЕРЖАТЬ','escape'),'diagram')
add(at('они сдвинули'),rp(5,'ПРЕГРАДУ УДАЛОСЬ СДВИНУТЬ'),'reconstruction')
add(at('и стали руками'),section('ПОСЛЕДНЯЯ ПРЕГРАДА — ЗЕМЛЯ','dig'),'diagram')
add(at('примерно через'),rp(3,'ОКОЛО 16 ЧАСОВ ПОД ЗЕМЛЁЙ'),'reconstruction')
add(at('все двадцать семь'),ap('victims_rescued','ВСЕ 27 ВЫБРАЛИСЬ'),'archive')
add(at('но самое'),ap('defendants','ИХ ПЛАН ВЫЯСНИЛСЯ ПОЗЖЕ'),'archive')
add(at('похитители хотели'),ap('mugshots','ОНИ ХОТЕЛИ $5 000 000'),'archive')
add(at('однако дети'),ap('victims_in_parade','ДЕТИ СПАСЛИСЬ РАНЬШЕ'),'archive')
add(at('предъявить требование'),ap('victims_rescued','ТРЕБОВАНИЕ О ВЫКУПЕ ОПОЗДАЛО'),'archive')
scenes.sort(key=lambda x:x['start'])
# Keep long passages visually legible without any pan/zoom or camera shake.
# Additional meaningful diagram variants split holds over 3 seconds.
expanded=[]
for i,s in enumerate(scenes):
 end=scenes[i+1]['start'] if i+1<len(scenes) else duration
 expanded.append(s)
 if end-s['start']>3.2:
  mid=(s['start']+end)/2
  alt=section('ВЫХОД ТОЛЬКО ЧЕРЕЗ ЛЮК','trap') if s['kind']=='diagram' and mid<at('водитель и старшие') and mid>at('в грузовой кузов') else None
  if alt is None:
   alt=opening('КАЛИФОРНИЯ • ИЮЛЬ 1976','ДЕТЕЙ УВЕЗЛИ С МАРШРУТА',1) if mid<at('а потом') else section('ЧЕРЕЗ ЛЮК НУЖНО ПРОБИТЬСЯ','escape') if mid>=at('водитель и старшие') else section('ЛЮК ПОД ЗЕМЛЁЙ','ladder')
  expanded.append({'start':mid,'image':alt,'kind':s['kind']})
scenes=expanded;manifest=[];plan=[]
for i,s in enumerate(scenes):
 end=scenes[i+1]['start'] if i+1<len(scenes) else duration
 f=p/f'card{i:02d}.png';s['image'].save(f);manifest.append(f"file '{f}'\noption framerate 30\nduration {end-s['start']:.8f}\n");plan.append({'start':s['start'],'end':end,'kind':s['kind'],'card':f.name})
manifest.append(f"file '{f}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest));(p/'shot_timing.json').write_text(json.dumps(plan,indent=2))
# Sentence-aware subtitles: keep two to five words, never carry the next sentence early.
text=(p/'narration.txt').read_text();sentences=re.split(r'[.!?]+',text);sizes=[];pending=0
for sentence in sentences:
 n=len(re.findall(r'[А-Яа-яЁё]+',sentence));pending+=n
 if pending>=2:sizes.append(pending);pending=0
if pending:sizes[-1]+=pending
assert sum(sizes)==len(words),(sum(sizes),len(words))
groups=[];cursor=0
for n in sizes:
 count=math.ceil(n/5);q,r=divmod(n,count)
 for j in range(count):k=q+(j<r);groups.append(words[cursor:cursor+k]);cursor+=k
assert all(2<=len(g)<=5 for g in groups)
def stamp(t):
 n=round(t*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'
ass='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: S,DejaVu Sans,56,&H00FFFFFF,&H000000FF,&H00101010,&H00101010,-1,0,0,0,100,100,0,0,1,4,1,5,90,170,0,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
for g in groups:
 rows=[];row=[]
 for w in g:
  token=w['text'].upper()
  if row and F(56).getlength(' '.join(row+[token]))>850:rows.append(' '.join(row));row=[]
  row.append(token)
 if row:rows.append(' '.join(row))
 txt=r'\N'.join(rows)
 for key in ['ИСЧЕЗЛИ','ДЕТЕЙ','ЗЕМЛЮ','ЛЮК','ВЫБРАЛИСЬ','МИЛЛИОНОВ','СПАСЛИСЬ']:txt=txt.replace(key,r'{\c&H70C8F4&}'+key+r'{\c&HFFFFFF&}')
 ass+=f'Dialogue: 0,{stamp(g[0]["start"])},{stamp(g[-1]["end"])},S,,0,0,0,,{{\\pos(500,1510)}}{txt}\n'
(p/'subtitles.ass').write_text(ass);(p/'words.json').write_text(json.dumps(words,ensure_ascii=False))
# The first deliverable is explicitly a preview, not an approved final.
out=p/'SNG_003_Chowchilla_PREVIEW_V2.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(p/'mix.wav'),'-vf',f'fps=30,ass={p/"subtitles.ass"},scale=1080:1920','-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-metadata','comment=Archival photographs: Rick Meyer, Joe Kennedy, Art Rogers / Los Angeles Times Photographic Collection, UCLA Library; CC BY 4.0 https://creativecommons.org/licenses/by/4.0/ . Scaled with captions. Mugshots: Alameda County Sheriffs Office, public domain. Full sources: https://github.com/kivan2215-lgtm/SNG_shorts/blob/main/production/SNG_003_SOURCES.md','-movflags','+faststart',str(out)],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p/'subtitles.ass'),str(p/'subtitles.srt')],check=True)
print(out.name,out.stat().st_size,flush=True)
