from PIL import Image,ImageDraw,ImageFont,ImageEnhance
from pathlib import Path
p=Path(__file__).parent
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def F(n):return ImageFont.truetype(FONT,n)
WHITE='#f4ede0';GOLD='#ffce77';BLUE='#7bc4d4';RED='#e39173';BG='#101c24'
def fittext(d,pos,text,size=44,fill=WHITE,maxwidth=950):
 while max(F(size).getlength(s) for s in text.split('\n'))>maxwidth:size-=1
 d.multiline_text(pos,text,font=F(size),fill=fill,anchor='mm',align='center',spacing=12)
def canvas(title):
 im=Image.new('RGB',(1080,1920),BG);d=ImageDraw.Draw(im)
 for y in range(1920):
  v=int(9*(1-abs(y-800)/1200));d.line((0,y,1080,y),fill=(14+v,23+v,32+v))
 d.rounded_rectangle((48,110,1032,1390),radius=35,fill='#192a34',outline='#354a56',width=2)
 fittext(d,(540,213),title,53)
 return im,d

def picture(title,source,credit):
 im,d=canvas(title)
 scale=min(1012/source.width,1010/source.height);pic=source.resize((round(source.width*scale),round(source.height*scale)),Image.Resampling.LANCZOS)
 x=(1080-pic.width)//2;y=805-pic.height//2;im.paste(pic,(x,y))
 d.rectangle((x,y,x+pic.width,y+pic.height),outline='#8e9ca1',width=2)
 fittext(d,(540,1340),credit,24,fill='#b9c8ca',maxwidth=980)
 return im

def opening(title,badge,which=0):
 r=Image.open(p/'recon.png').convert('RGB');col=which%2;row=which//2;pic=r.crop((col*512+3,row*512+3,(col+1)*512-3,(row+1)*512-3)).resize((1080,1080),Image.Resampling.LANCZOS)
 im=Image.new('RGB',(1080,1920),BG);im.paste(pic,(0,160));d=ImageDraw.Draw(im)
 d.rectangle((0,0,1080,160),fill='#111b22');fittext(d,(540,92),title,52)
 d.rounded_rectangle((54,1140,1026,1345),radius=25,fill='#15212a',outline=GOLD,width=3)
 fittext(d,(540,1230),badge,62,fill=GOLD);fittext(d,(540,1380),'РЕКОНСТРУКЦИЯ',23,fill='#aebcc2')
 return im

def locator():return opening('КАЛИФОРНИЯ • 15 ИЮЛЯ 1976','АВТОБУС ЕХАЛ ДОМОЙ',1)

def arrow(d,a,b,color=GOLD,width=8):
 import math
 d.line((*a,*b),fill=color,width=width)
 ang=math.atan2(b[1]-a[1],b[0]-a[0]);size=24
 pts=[b,(b[0]-size*math.cos(ang-.6),b[1]-size*math.sin(ang-.6)),(b[0]-size*math.cos(ang+.6),b[1]-size*math.sin(ang+.6))];d.polygon(pts,fill=color)

def section(title,mode):
 im,d=canvas(title)
 # Legible cutaway: earth, the short access shaft, metal trailer and one exit.
 d.rounded_rectangle((76,372,1004,692),radius=18,fill='#65513e')
 for x in range(85,1000,35):
  for y in range(390,690,40):d.line((x,y,x+17,y+12),fill='#8a7255',width=2)
 d.rectangle((76,360,1004,379),fill='#ad9170')
 fittext(d,(310,422),'ЗЕМЛЯ КАРЬЕРА',28,fill='#f3dfbf',maxwidth=400)
 d.polygon([(99,748),(944,748),(985,710),(140,710)],fill='#3c5967')
 d.polygon([(944,748),(985,710),(985,1218),(944,1260)],fill='#132630')
 d.rounded_rectangle((99,748,944,1260),radius=20,fill='#263b47',outline=BLUE,width=4)
 for x in range(120,940,40):d.line((x,765,x,1238),fill='#39515d',width=2)
 d.rectangle((605,640,818,750),fill='#121d24',outline=BLUE,width=4)
 # Hatch label pointer.
 fittext(d,(896,680),'ЛЮК',29,fill=GOLD,maxwidth=160);arrow(d,(855,700),(810,722),GOLD,4)
 fittext(d,(315,820),'ГРУЗОВОЙ\nКУЗОВ',37,maxwidth=360)
 people=mode in ['trap','weight']
 if people:
  for j in range(27):
   x=165+(j%9)*43;y=955+(j//9)*78;c=BLUE if j==26 else GOLD
   d.ellipse((x-8,y-20,x+8,y-4),fill=c);d.rounded_rectangle((x-10,y,x+10,y+31),radius=6,fill=c)
  fittext(d,(330,1200),'26 ДЕТЕЙ + ВОДИТЕЛЬ',25,maxwidth=420)
 if mode=='ladder':
  for x in [650,775]:d.line((x,645,x,1180),fill=GOLD,width=9)
  for y in range(690,1170,55):d.line((650,y,775,y),fill=GOLD,width=8)
  arrow(d,(520,900),(520,1110),BLUE)
  fittext(d,(330,1005),'ВХОД ЧЕРЕЗ\nЛЕСТНИЦУ',30,fill=BLUE,maxwidth=340)
 else:
  # The lid is separate from the added sheet and weights above it.
  d.rectangle((600,630,823,647),fill='#b7c4c9',outline=WHITE,width=2)
 if mode in ['trap','weight']:
  d.rectangle((570,601,855,622),fill='#8c9ba6',outline=WHITE,width=2)
  for x in [605,735]:
   d.rounded_rectangle((x,515,x+93,599),radius=7,fill='#20303b',outline=GOLD,width=3)
   d.rectangle((x+15,505,x+31,516),fill=GOLD);d.rectangle((x+60,505,x+76,516),fill=GOLD)
   fittext(d,(x+46,557),'45 кг',21,fill=GOLD,maxwidth=85)
  fittext(d,(540,317),'ДВА АККУМУЛЯТОРА НА МЕТАЛЛЕ',27,fill=GOLD)
  fittext(d,(305,540),'ВЫХОД\nПЕРЕКРЫТ',35,fill=RED,maxwidth=350);arrow(d,(480,575),(569,608),RED,5)
  arrow(d,(715,455),(715,501),RED,6)
 if mode in ['mattress','escape','dig']:
  for j in range(6):
   y=1190-j*61;d.rounded_rectangle((574,y,872,y+52),radius=15,fill='#b39472',outline='#e4c39b',width=3)
   for x in range(595,860,50):d.ellipse((x,y+20,x+5,y+25),fill='#e4c39b')
  fittext(d,(330,1000),'МАТРАСЫ\nВМЕСТО ЛЕСТНИЦЫ',30,fill=GOLD,maxwidth=395)
  arrow(d,(920,1170),(920,825),GOLD,6)
 if mode in ['escape','dig']:
  # Tilted lid, wood wedge, clear direction of the effort.
  d.rectangle((603,625,821,650),fill='#16252e')
  d.polygon([(602,625),(831,578),(835,595),(605,643)],fill='#c5d0d3',outline=WHITE)
  d.polygon([(767,640),(807,640),(806,603)],fill='#b68854',outline=GOLD)
  fittext(d,(355,552),'ПОДПОРКА\nИЗ ДЕРЕВА',29,fill=GOLD,maxwidth=350);arrow(d,(492,581),(774,623),GOLD,4)
  arrow(d,(710,800),(710,681),GOLD,7)
 if mode=='dig':
  d.rectangle((605,350,818,565),fill='#253c46')
  arrow(d,(700,478),(585,406),BLUE,6);arrow(d,(742,478),(868,406),BLUE,6)
  fittext(d,(540,315),'РАЗГРЕСТИ ЗЕМЛЮ НАД ЛЮКОМ',27,fill=BLUE)
 if mode=='roof':
  d.line((115,753,280,760,460,784,640,800,800,780,940,750),fill=RED,width=9)
  arrow(d,(550,820),(550,915),RED,7)
  fittext(d,(420,1030),'КРЫША ПРОГИБАЛАСЬ',30,fill=RED,maxwidth=650)
 # A simple state legend is specific to the current step, no invented geometry.
 legend={'ladder':'ВХОД СВЕРХУ → СПУСК В КУЗОВ','trap':'ЛЕСТНИЦУ УБРАЛИ • ЛЮК ЗАБЛОКИРОВАН','weight':'ВЕС УДЕРЖИВАЕТ ЛЮК ЗАКРЫТЫМ','mattress':'ШАГ 1 • ПОДНЯТЬСЯ К ЛЮКУ','escape':'ШАГ 2 • ПРИПОДНЯТЬ И ПОДПЕРЕТЬ','dig':'ШАГ 3 • ОСВОБОДИТЬ ВЫХОД','roof':'ОПАСНОСТЬ ВНУТРИ КУЗОВА НАРАСТАЛА'}[mode]
 fittext(d,(540,1310),legend,27,fill=GOLD)
 fittext(d,(540,1360),'ПОЯСНЯЮЩАЯ СХЕМА • НЕ В МАСШТАБЕ',22,fill='#9eafb7')
 return im
