from pathlib import Path
import json,subprocess,math,shutil
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent;src=p.parent/'short_004_juliane_v2';duration=69.7
GOLD='#ffd28a';BLUE='#8bd6df';WHITE='#f1eee2';MUTED='#a2b9bd'
def F(n):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',n)
def txt(d,pos,t,n=39,c=WHITE,w=970):
 while max(F(n).getlength(s) for s in t.split('\n'))>w:n-=1
 d.multiline_text(pos,t,font=F(n),fill=c,anchor='mm',align='center',spacing=14)
def bg(title):
 im=Image.new('RGB',(1080,1920),'#101f28');d=ImageDraw.Draw(im);txt(d,(540,118),title,50);return im,d
def photo(title,path,credit,note=''):
 im,d=bg(title);pic=Image.open(path).convert('RGB');f=min(1020/pic.width,1060/pic.height);pic=pic.resize((round(pic.width*f),round(pic.height*f)),Image.Resampling.LANCZOS);x=(1080-pic.width)//2;y=780-pic.height//2;im.paste(pic,(x,y));d.rectangle((x,y,x+pic.width,y+pic.height),outline='#6f8c97',width=2)
 if note:txt(d,(540,1140),note,29,GOLD)
 parts=credit.split(' • ');credit=(' • '.join(parts[:2])+'\n'+' • '.join(parts[2:])) if len(credit)>65 and len(parts)>2 else credit
 txt(d,(540,1360),credit,25,MUTED);return im
recon=Image.open(src/'recon.png').convert('RGB');panels=[recon.crop(b) for b in [(3,3,509,503),(515,3,1021,503),(3,512,509,1009),(515,512,1021,1009),(3,1017,509,1533),(515,1017,1021,1533)]]
more=Image.open(src/'more.png').convert('RGB');W,H=more.size;panels +=[more.crop((c*W//3+3,r*H//3+3,(c+1)*W//3-3,(r+1)*H//3-3)) for r in range(3) for c in range(3)]
def reconstruction(idx,title):
 im,d=bg(title);im.paste(panels[idx].resize((1080,1080),Image.Resampling.LANCZOS),(0,220));txt(d,(540,1360),'РЕКОНСТРУКЦИЯ',25,MUTED);return im

def data(title,kind):
 im,d=bg(title);d.rounded_rectangle((70,310,1010,1290),radius=35,fill='#19323e',outline='#52717c',width=2)
 if kind=='fall':
  # Simple altitude scale, not an explanation of the survival mechanism.
  for y in range(450,1120,70):d.line((240,y,285,y),fill=BLUE,width=3)
  d.line((250,430,250,1120),fill=BLUE,width=7)
  d.line((540,520,540,1000),fill=GOLD,width=12);d.polygon([(540,1030),(505,970),(575,970)],fill=GOLD)
  txt(d,(540,430),'≈ 3000 М',89,GOLD);txt(d,(540,1160),'БЕЗ ПАРАШЮТА',47)
 elif kind=='flight':
  for y,a,b in [(470,'ДАТА','24 ДЕКАБРЯ 1971'),(730,'МЕСТО','ПЕРУ'),(990,'РЕЙС','LANSA 508')]:
   txt(d,(540,y-60),a,26,BLUE);txt(d,(540,y+20),b,52,GOLD)
 elif kind=='injury':
  for y,a,b in [(460,'КЛЮЧИЦА','ПЕРЕЛОМ'),(740,'ОЧКИ','ПОТЕРЯНЫ'),(1020,'ОБУВЬ','ОДИН КРОССОВОК')]:
   txt(d,(540,y-50),a,30,BLUE);txt(d,(540,y+40),b,49,GOLD)
 else:
  for j in range(92):
   x=170+(j%12)*66;y=440+(j//12)*66;c=GOLD if j==91 else '#536b76';d.ellipse((x,y,x+27,y+27),fill=c)
  txt(d,(540,1100),'92 НА БОРТУ',62);txt(d,(540,1190),'1 ВЫЖИВШАЯ',50,GOLD)
 txt(d,(540,1360),'ПОЯСНЯЮЩАЯ ИНФОГРАФИКА',24,MUTED);return im

def arrow(d,a,b,c=GOLD):
 d.line((*a,*b),fill=c,width=8);angle=math.atan2(b[1]-a[1],b[0]-a[0]);d.polygon([b,(b[0]-24*math.cos(angle-.55),b[1]-24*math.sin(angle-.55)),(b[0]-24*math.cos(angle+.55),b[1]-24*math.sin(angle+.55))],fill=c)
terrain=Image.open(p/'terrain.png').convert('RGBA').resize((1040,945),Image.Resampling.LANCZOS);anchors=json.loads((p/'terrain_anchors.json').read_text())
def point(k):x,y,_=anchors[k];return(20+round(x*1040),280+round((1-y)*945))
def watershed(stage):
 titles=['НЕ ПОТЕРЯТЬ РУЧЕЙ','РУЧЕЙ СОЕДИНЯЕТСЯ С РЕКОЙ','ИСКАТЬ ПРИЗНАКИ ЖИЛЬЯ'];im,d=bg(titles[stage]);im.paste(terrain,(20,280),terrain);d=ImageDraw.Draw(im)
 for i,s in enumerate(['1  РУЧЕЙ','2  РЕКА','3  ЛЮДИ?']):
  x=60+i*330;d.rounded_rectangle((x,220,x+300,275),radius=15,fill='#21404a',outline=GOLD if i==stage else '#526b76',width=3);txt(d,(x+150,248),s,29,GOLD if i==stage else MUTED,w=280)
 a,b,c=point('stream'),point('join'),point('river')
 if stage==0:arrow(d,a,b,BLUE)
 if stage>=1:arrow(d,b,c,GOLD)
 selected=[a,b,point('bank')][stage];rad=20;d.ellipse((selected[0]-rad,selected[1]-rad,selected[0]+rad,selected[1]+rad),outline=GOLD,width=5)
 if stage==2:txt(d,selected,'?',34,GOLD)
 texts=[('СОВЕТ ОТЦА','ДЕРЖАТЬСЯ ТЕКУЩЕЙ ВОДЫ'),('ПОНЯТНОЕ НАПРАВЛЕНИЕ','ОТ МАЛОГО РУЧЬЯ К БОЛЬШОЙ РЕКЕ'),('ВОЗМОЖНОСТЬ, НЕ ГАРАНТИЯ','У РЕКИ МОГУТ ОКАЗАТЬСЯ ЛЮДИ')][stage]
 d.rounded_rectangle((70,1160,1010,1295),radius=22,fill='#173441',outline='#4c6c77',width=2);txt(d,(540,1197),texts[0],25,BLUE);txt(d,(540,1252),texts[1],32,GOLD)
 txt(d,(540,1360),'УСЛОВНЫЙ ПРИНЦИП • НЕ КАРТА ЕЁ МАРШРУТА',24,MUTED);return im
scenes=[]
def add(t,im,key):scenes.append({'start':t,'image':im,'asset_id':key})
add(0,reconstruction(0,'САМОЛЁТ РАЗВАЛИЛСЯ В НЕБЕ'),'recon_plane')
add(2.182333,reconstruction(1,'ЕЙ БЫЛО 17 ЛЕТ'),'recon_fall')
add(3.898041,data('ПАДЕНИЕ БЕЗ ПАРАШЮТА','fall'),'diagram_height')
add(7.344416,reconstruction(8,'НО ОНА ВЫЖИЛА'),'recon_seats')
add(8.461,photo('САМОЛЁТ ТАКОГО ТИПА',src/'plane.png','CLINT GROVES • ОКЛЕНД, 1968 • GFDL 1.2','LOCKHEED L-188 • НЕ СНИМОК КАТАСТРОФЫ'),'archive_plane1968')
add(11.647249,data('ЮЛИАНА ЛЕТЕЛА С МАТЕРЬЮ','flight'),'diagram_flight')
add(13.503874,reconstruction(6,'В ПОЛЁТЕ НАД ПЕРУ'),'recon_cabin')
add(15.360499,reconstruction(7,'УДАР МОЛНИИ'),'recon_window')
# One uninterrupted shot replaces the old repeated fall enlargements.
add(16.685415,reconstruction(2,'ПОСЛЕ ПАДЕНИЯ — ДЖУНГЛИ'),'recon_girl_forest')
add(20.800000,photo('ДЖУНГЛИ РАЙОНА ПАНГУАНЫ',p/'Panguana-Lupuna-2008-2.jpg','KLAUS SCHÖNITZER • ПАНГУАНА, 2008 • CC BY-SA 3.0'),'photo_forest2008')
add(24.812,reconstruction(9,'ОНА ПОТЕРЯЛА ОЧКИ'),'recon_glasses')
add(26.172,data('ТРАВМЫ ПОСЛЕ ПАДЕНИЯ','injury'),'diagram_injuries')
add(29.936,photo('ТРОПИЧЕСКИЙ ЛЕС',p/'Panguana-2004-5.JPG','KLAUS SCHÖNITZER • ПАНГУАНА, 2004 • CC BY-SA 3.0'),'photo_forest2004')
add(33.478,reconstruction(12,'ЕДЫ ПОЧТИ НЕ БЫЛО'),'recon_sweets')
add(34.786,reconstruction(11,'ПОИСКИ НАД ЛЕСОМ'),'recon_search')
add(36.932,reconstruction(10,'КРОНЫ СКРЫВАЛИ ЕЁ'),'recon_canopy')
add(38.368,photo('ЗНАНИЯ ОТЦА-БИОЛОГА',p/'Panguana-1971.jpg','СТАНЦИЯ ЕЁ РОДИТЕЛЕЙ • ПАНГУАНА, 1971 • CC BY-SA 3.0'),'archive_station1971')
for t,k in [(41.187,0),(43.934,1),(45.539,2)]:add(t,watershed(k),'watershed_stage'+str(k))
add(47.70,reconstruction(3,'ОНА ПОШЛА ВДОЛЬ РУЧЬЯ'),'recon_creek')
add(49.923,reconstruction(13,'РУЧЕЙ ВЕДЁТ К РЕКЕ'),'recon_confluence')
add(51.448,reconstruction(4,'ДНИ ШЛИ. СИЛЫ ЗАКАНЧИВАЛИСЬ'),'recon_rain')
add(53.70,photo('РЕКА В РАЙОНЕ ПАНГУАНЫ',p/'Panguana-2004-3.JPG','РЕКА ЛЬЮЛЬЯПИЧИС • K. SCHÖNITZER, 2004 • CC BY-SA 3.0'),'photo_river2004')
add(55.41,reconstruction(5,'НАКОНЕЦ ПОКАЗАЛАСЬ ХИЖИНА'),'recon_shelter')
add(57.927,reconstruction(14,'ТУДА ВЕРНУЛИСЬ ЛЕСОРУБЫ'),'recon_workers')
add(61.760,photo('ПОСЛЕ 11 ДНЕЙ В ДЖУНГЛЯХ',src/'photo1.jpg','ЮЛИАНА КЁПКЕ • РЕАЛЬНОЕ ФОТО, 2019 • CC BY-SA 2.0'),'portrait_ceremony2019')
add(65.070,data('ЕДИНСТВЕННАЯ ВЫЖИВШАЯ','survivors'),'diagram_survivors')
add(67.71,photo('ЮЛИАНА КЁПКЕ',src/'photo0.jpg','РЕАЛЬНОЕ ФОТО, 2019 • CANCILLERÍA DEL PERÚ • CC BY-SA 2.0'),'portrait2019')
scenes.sort(key=lambda s:s['start']);assert len({s['asset_id'] for s in scenes})==len(scenes)
plan=[];manifest=[]
for i,s in enumerate(scenes):
 end=scenes[i+1]['start'] if i+1<len(scenes) else duration;f=p/f'card{i:02d}.png';s['image'].save(f);manifest.append(f"file '{f}'\noption framerate 30\nduration {end-s['start']:.8f}\n");plan.append({'start':s['start'],'end':end,'asset_id':s['asset_id']})
manifest.append(f"file '{f}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest));(p/'shot_timing.json').write_text(json.dumps(plan,indent=2))
shutil.copy(src/'subtitles.ass',p/'subtitles.ass');shutil.copy(src/'subtitles.srt',p/'subtitles.srt')
out=p/'SNG_004_Juliane_Koepcke_PREVIEW_V3.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(src/'SNG_004_Juliane_Koepcke_PREVIEW_V2.mp4'),'-map','0:v:0','-map','1:a:0','-vf',f'fps=30,ass={p/"subtitles.ass"}','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','copy','-t',str(duration),'-metadata','comment=Archive and context photos: Maria or Hans-Wilhelm Koepcke, Klaus Schonitzer (CC BY-SA 3.0); Clint Groves (GFDL 1.2); Cancilleria del Peru (CC BY-SA 2.0). Full credits and license copies: https://github.com/kivan2215-lgtm/SNG_shorts/blob/main/production/SNG_004_SOURCES.md','-movflags','+faststart',str(out)],check=True)
print('Rendered',len(scenes),'distinct shots;',out.stat().st_size,'bytes',flush=True)
