import bpy,math,random,json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
from pathlib import Path
p=Path(__file__).parent;bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_denoising=False;s.render.film_transparent=True;s.render.resolution_x=1100;s.render.resolution_y=1000;s.render.resolution_percentage=100
s.world.color=(.2,.25,.23)
def mat(n,c,metal=0,rough=.5):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough;return m
earth=mat('Soil',(.12,.16,.08));water=mat('River',(.012,.22,.30),.05,.36);stream=mat('Stream',(.05,.46,.55),.05,.38);leaf=[mat('Canopy'+str(i),c) for i,c in enumerate([(.035,.16,.10),(.09,.25,.15),(.16,.32,.16)])];trunk=mat('Trunk',(.17,.10,.045));rim=mat('Earth cross section',(.21,.15,.09))
def cube(loc,size,m,bev=.05):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);be=o.modifiers.new('Bevel','BEVEL');be.width=bev;be.segments=3;o.modifiers.new('Normal','WEIGHTED_NORMAL');return o
cube((0,0,-.42),(8,8,.72),rim,.18);cube((0,0,-.04),(8,8,.15),earth,.18)
def riverx(y):return .3+.55*math.sin(y*.9)
def channel(points,width,m,z=.07):
 verts=[]
 for x,y in points:verts.extend([(x-width/2,y,z),(x+width/2,y,z)])
 faces=[(2*i,2*i+1,2*i+3,2*i+2) for i in range(len(points)-1)];me=bpy.data.meshes.new('water');me.from_pydata(verts,[],faces);o=bpy.data.objects.new('Flow',me);bpy.context.collection.objects.link(o);o.data.materials.append(m)
river=[(riverx(-4+i*.08),-4+i*.08) for i in range(101)];channel(river,.68,water)
# Tributary visibly joins the larger river, with no claim of actual route coordinates.
trib=[(-3.8+(riverx(.3)+3.8)*i/50,2.8-2.5*i/50+.12*math.sin(math.pi*i/50)*math.sin(i*.3)) for i in range(51)];channel(trib,.22,stream,.08)
r=random.Random(1971)
for i in range(210):
 x=r.uniform(-3.7,3.7);y=r.uniform(-3.7,3.7)
 if abs(x-riverx(y))<.65 or any((x-a)**2+(y-b)**2<.18 for a,b in trib):continue
 h=r.uniform(.25,.55);cube((x,y,h/2),(.035,.035,h),trunk,.005)
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=r.uniform(.19,.30),location=(x,y,h));o=bpy.context.object;o.scale=(1,1,.7);o.data.materials.append(r.choice(leaf))
 for poly in o.data.polygons:poly.use_smooth=True
for loc,power,size,color in [((0,-3,9),1700,7,(1,.87,.65)),((-5,4,6),1600,6,(.55,.82,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.data.color=color;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(8,-11,13));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,.1))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=12;s.camera=cam;bpy.context.view_layer.update()
points={'stream':(-2.4,1.9,.15),'join':(riverx(.3),.3,.15),'river':(riverx(-2),-2,.15),'bank':(1.2,-2.7,.15)}
(p/'terrain_anchors.json').write_text(json.dumps({k:list(world_to_camera_view(s,cam,Vector(v))) for k,v in points.items()},indent=2));s.render.filepath=str(p/'terrain.png');bpy.ops.render.render(write_still=True);bpy.ops.wm.save_as_mainfile(filepath=str(p/'terrain.blend'))
