from pathlib import Path
import json,subprocess,math,wave,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent
words=json.loads((p/'boundaries.json').read_text());words=[w for w in words if w['type']=='WordBoundary']
dur=math.ceil(float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p/'v0.mp3')]))*30)/30
print('DURATION',dur,flush=True)
def at(word):
 return next(w['offset']/1e7 for w in words if w['text'].lower().strip('.,:;!?')==word.lower())
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def text(d,xy,s,size=48,col='#f4f0df',width=930):
 while max(ImageFont.truetype(font,size).getlength(t) for t in s.split('\n'))>width:size-=1
 d.multiline_text(xy,s,font=ImageFont.truetype(font,size),fill=col,anchor='mm',align='center',spacing=18)
grid=Image.open(p/'recon.png').convert('RGB');W,H=grid.size
panels=[grid.crop((c*W//3+4,y0,(c+1)*W//3-4,y1)) for y0,y1 in [(3,274),(283,611),(622,921),(933,1251)] for c in range(3)]
def card(i,title):
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im)
 pic=panels[i].copy();pic.thumbnail((1080,1080));scale=min(1080/pic.width,1080/pic.height);pic=pic.resize((round(pic.width*scale),round(pic.height*scale)),Image.Resampling.LANCZOS);im.paste(pic,((1080-pic.width)//2,760-pic.height//2));text(d,(540,120),title,48);text(d,(540,1350),'ХУДОЖЕСТВЕННАЯ РЕКОНСТРУКЦИЯ',24,'#9bb4bb');return im

def diagram():
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im);text(d,(540,130),'ПОЧЕМУ ОН МОГ ДЫШАТЬ',46)
 d.rounded_rectangle((90,380,990,1180),radius=50,fill='#172d38',outline='#a9bcc4',width=5)
 d.rectangle((95,770,985,1130),fill='#175170');d.line((95,770,985,770),fill='#68c2d4',width=5)
 text(d,(540,520),'ВОЗДУШНЫЙ КАРМАН',44,'#ffd28a');text(d,(540,620),'Воздух сохранился\nвнутри перевёрнутого судна',32)
 text(d,(540,940),'ВОДА',52,'#8dd9e8');text(d,(540,1260),'ГЛУБИНА ≈ 30 МЕТРОВ',39,'#ffd28a');text(d,(540,1350),'СХЕМА ПРИНЦИПА • НЕ ПЛАН JASCON-4',23,'#9bb4bb');return im

def endcard():
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im);text(d,(540,370),'JASCON-4',80,'#ffd28a');text(d,(540,500),'НИГЕРИЯ • 26 МАЯ 2013',32)
 text(d,(540,760),'1 ВЫЖИВШИЙ',65);text(d,(540,890),'11 ПОГИБШИХ',50,'#9bb4bb');text(d,(540,1150),'Обнаружение записано\nкамерой водолаза',39);return im
scenes=[(0,card(0,'ОН ИСКАЛ ПОГИБШИХ')),(at('Нигерия'),card(1,'НИГЕРИЯ • МАЙ 2013')),(at('затонул'),card(2,'ОКОЛО 30 МЕТРОВ ПОД ВОДОЙ')),(at('борту'),card(3,'12 ЧЕЛОВЕК НА БОРТУ')),(at('Корабельный'),card(4,'ХАРРИСОН ОКЕНЕ • ПОВАР')),(at('воздушном'),diagram()),(at('Вокруг'),card(5,'ТЕМНОТА И ХОЛОД')),(at('сутки'),card(6,'24 ЧАСА')),(at('вторые'),card(7,'48 ЧАСОВ')),(at('Спустя'),card(8,'ОКОЛО 60 ЧАСОВ')),(at('повар'),card(9,'ОН ПРОТЯНУЛ РУКУ')),(at('нашли'),card(10,'ЕГО НАШЛИ ЖИВЫМ')),(at('декомпрессия'),card(11,'СПАСЕНИЕ ПРОДОЛЖАЛОСЬ')),(at('единственным'),endcard())]
# 'повар' occurs first in introduction; use last occurrence for discovery.
scenes[10]=(max(w['offset']/1e7 for w in words if w['text'].lower().strip('.,')=='повар'),scenes[10][1])
scenes.sort(key=lambda x:x[0]);manifest=[];plan=[]
for i,(start,im) in enumerate(scenes):
 end=scenes[i+1][0] if i+1<len(scenes) else dur;f=p/f'card{i:02}.png';im.save(f);manifest.append(f"file '{f}'\noption framerate 30\nduration {end-start:.8f}\n");plan.append({'start':start,'end':end,'file':f.name})
manifest.append(f"file '{f}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest));(p/'shot_timing.json').write_text(json.dumps(plan,indent=2))
header=(p.parent/'short_004_juliane_v2/subtitles.ass').read_text().split('Dialogue:')[0]
def stamp(t):
 h=int(t//3600);m=int(t//60)%60;s=t%60;return f'{h}:{m:02}:{s:05.2f}'
lines=[];srt=[]
for i in range(0,len(words),4):
 g=words[i:i+4];a=g[0]['offset']/1e7;b=(words[i+4]['offset']/1e7 if i+4<len(words) else dur)
 ts=[w['text'].upper() for w in g];label=' '.join(ts[:2])+('\\N'+' '.join(ts[2:]) if len(ts)>2 else '')
 for kw in ['ТЕМНОТА','ВОЗДУХА','ЖИВОГО','РУКУ','ДЕКОМПРЕССИЯ','ВЫЖИВШИМ']:
  label=label.replace(kw,'{\\c&H8AD2FF&}'+kw+'{\\c&HFFFFFF&}')
 lines.append(f'Dialogue: 0,{stamp(a)},{stamp(b)},S,,0,0,0,,{{\\pos(500,1510)}}{label}\n')
 srt.append(f'{len(srt)+1}\n'+stamp(a).replace('.',',')+' --> '+stamp(b).replace('.',',')+'\n'+' '.join(ts)+'\n\n')
(p/'subtitles.ass').write_text(header+''.join(lines));(p/'subtitles.srt').write_text(''.join(srt))
# Original restrained ambient score and effects, generated locally; no borrowed recordings.
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p/'v0.mp3'),'-ar','48000','-ac','1',str(p/'voice.wav')],check=True)
with wave.open(str(p/'voice.wav')) as w: voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
n=round(dur*48000);t=np.arange(n)/48000;v=np.pad(voice,(0,max(0,n-len(voice))))[:n];rng=np.random.default_rng(5)
bed=.008*np.sin(2*np.pi*47*t)+.004*np.sin(2*np.pi*70.5*t)+.001*rng.normal(size=n)
rescue=at('нашли');bed*=np.where(t<rescue,1,.3);bed*=np.minimum(t/1.5,1)*np.minimum((dur-t)/1.5,1)
for start in [at('затонул'),at('сутки'),at('вторые')]:
 z=np.maximum(t-start,0);bed+=np.where(t>=start,.015*np.exp(-4*z)*np.sin(2*np.pi*133*z),0)
mix=np.clip(v+bed,-.98,.98)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes((mix*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(p/'mix.wav'),'-vf',f'fps=30,ass={p/"subtitles.ass"}','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-t',str(dur),'-movflags','+faststart',str(p/'SNG_005_Okene_PREVIEW.mp4')],check=True)
print('DONE',flush=True)
