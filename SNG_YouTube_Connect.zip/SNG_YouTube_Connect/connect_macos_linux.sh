#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -f client_secret.json ]; then
  echo 'Save your Google Desktop OAuth client JSON as client_secret.json in this folder.'
  echo 'Follow README_RU.md, then run this script again.'
  exit 1
fi
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python youtube.py authorize --client-secret client_secret.json
echo 'Connected. Follow step 4 in README_RU.md for cloud access.'
echo 'Keep .secrets/token.json private. Do not send it in chat or upload it to GitHub.'
