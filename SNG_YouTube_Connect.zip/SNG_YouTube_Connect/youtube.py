#!/usr/bin/env python3
"""Authorize, inspect, and upload to the user's YouTube channel.

preview never contacts Google. authorize opens Google's account consent page.
status is read-only. upload is the only command that creates a video.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

class SetupError(Exception):
    """An actionable message that never contains credentials."""


HERE = Path(__file__).resolve().parent
SCOPES = [
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.readonly',
]

def save_private(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_suffix(path.suffix + '.tmp')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)

def token_path() -> Path:
    return Path(os.environ.get('YOUTUBE_TOKEN_FILE', str(HERE / '.secrets/token.json'))).expanduser()

def credentials():
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    path = token_path()
    if os.environ.get('YOUTUBE_TOKEN_JSON'):
        info = json.loads(os.environ['YOUTUBE_TOKEN_JSON'])
    elif all(os.environ.get(k) for k in ('YOUTUBE_CLIENT_ID', 'YOUTUBE_CLIENT_SECRET', 'YOUTUBE_REFRESH_TOKEN')):
        info = {
            'client_id': os.environ['YOUTUBE_CLIENT_ID'],
            'client_secret': os.environ['YOUTUBE_CLIENT_SECRET'],
            'refresh_token': os.environ['YOUTUBE_REFRESH_TOKEN'],
            'token_uri': 'https://oauth2.googleapis.com/token',
        }
    elif path.is_file():
        info = json.loads(path.read_text())
    else:
        raise SetupError('YouTube ещё не подключён: настройте OAuth-доступ в секретах среды или выполните authorize на своём компьютере.')
    creds = Credentials.from_authorized_user_info(info, scopes=SCOPES)
    if not creds.valid:
        if not creds.refresh_token:
            raise SetupError('Нужен OAuth refresh token для повторных загрузок.')
        creds.refresh(Request())
        if path.is_file() and not any(os.environ.get(k) for k in ('YOUTUBE_TOKEN_JSON', 'YOUTUBE_REFRESH_TOKEN')):
            save_private(path, json.loads(creds.to_json()))
    return creds

def service(creds):
    from googleapiclient.discovery import build
    return build('youtube', 'v3', credentials=creds, cache_discovery=False)

def channel(api):
    result = api.channels().list(part='id,snippet', mine=True).execute()
    items = result.get('items', [])
    if len(items) != 1:
        raise SetupError('Не удалось однозначно определить канал. При входе в Google выберите нужный YouTube-канал.')
    item = items[0]
    return {'id': item['id'], 'title': item['snippet']['title'], 'url': 'https://www.youtube.com/channel/' + item['id']}

def authorize(args):
    from google_auth_oauthlib.flow import InstalledAppFlow
    config = json.loads(args.client_secret.read_text())
    if 'installed' not in config:
        raise SetupError('Для локального входа нужен OAuth-клиент типа Desktop app. Создайте клиент типа Desktop app в Google Auth Platform.')
    flow = InstalledAppFlow.from_client_config(config, SCOPES, autogenerate_code_verifier=True)
    creds = flow.run_local_server(
        host='127.0.0.1', port=0, open_browser=True, access_type='offline',
        prompt='select_account consent',
        success_message='YouTube подключён. Можно закрыть эту вкладку.',
    )
    identity = channel(service(creds))
    save_private(token_path(), json.loads(creds.to_json()))
    print(json.dumps({'connected_channel': identity, 'token_saved': str(token_path())}, ensure_ascii=False, indent=2))

def metadata(path: Path, privacy=None):
    body = json.loads(path.read_text())
    title = body.get('snippet', {}).get('title', '')
    if not title or len(title) > 100:
        raise SetupError('Заголовок должен содержать от 1 до 100 символов.')
    if len(body.get('snippet', {}).get('description', '')) > 5000:
        raise SetupError('Описание длиннее 5000 символов.')
    status = body.setdefault('status', {})
    status['privacyStatus'] = privacy or status.get('privacyStatus', 'private')
    if status['privacyStatus'] not in ('private', 'unlisted', 'public'):
        raise SetupError('Неизвестный режим доступа к ролику.')
    return body

def upload(args):
    from googleapiclient.http import MediaFileUpload
    if not args.video.is_file():
        raise SetupError('Видеофайл не найден.')
    body = metadata(args.metadata, args.privacy)
    api = service(credentials())
    identity = channel(api)
    if identity['id'] != args.channel:
        raise SetupError('Подключён другой канал. Загрузка остановлена до отправки видео.')
    digest = hashlib.sha256()
    with args.video.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    job_path = HERE / '.state' / f"{identity['id']}_{digest.hexdigest()}.json"
    if job_path.exists():
        job = json.loads(job_path.read_text())
        if job.get('video_id'):
            print('Уже загружено: https://youtu.be/' + job['video_id'])
            return
        raise SetupError('Найдена незавершённая попытка загрузки этого файла. Сначала проверьте YouTube Studio, чтобы не создать дубликат.')
    save_private(job_path, {'state': 'uploading', 'channel': identity, 'file_sha256': digest.hexdigest()})
    media = MediaFileUpload(str(args.video), mimetype='video/mp4', chunksize=8 * 1024 * 1024, resumable=True)
    request = api.videos().insert(part='snippet,status', body=body, media_body=media, notifySubscribers=False)
    result = None
    while result is None:
        _, result = request.next_chunk(num_retries=3)
    job = {'state': 'uploaded', 'channel': identity, 'video_id': result['id'], 'requested_privacy': body['status']['privacyStatus']}
    save_private(job_path, job)
    print(json.dumps(job, ensure_ascii=False, indent=2))
    print('https://youtu.be/' + result['id'])

def main(argv=None):
    parser = argparse.ArgumentParser(description='Подключение YouTube и загрузка Shorts')
    sub = parser.add_subparsers(dest='command', required=True)
    auth = sub.add_parser('authorize', help='Разовый вход через браузер на вашем компьютере')
    auth.add_argument('--client-secret', type=Path, required=True)
    sub.add_parser('status', help='Показать подключённый канал, без загрузки роликов')
    for name in ('preview', 'upload'):
        cmd = sub.add_parser(name)
        cmd.add_argument('--metadata', type=Path, default=HERE / 'sultana_metadata.json')
        cmd.add_argument('--privacy', choices=('private','unlisted','public'))
        if name == 'upload':
            cmd.add_argument('--video', type=Path, required=True)
            cmd.add_argument('--channel', required=True, help='Ожидаемый ID канала из команды status')
    args = parser.parse_args(argv)
    try:
        if args.command == 'authorize': authorize(args)
        elif args.command == 'status': print(json.dumps(channel(service(credentials())), ensure_ascii=False, indent=2))
        elif args.command == 'preview': print(json.dumps(metadata(args.metadata, args.privacy), ensure_ascii=False, indent=2))
        else: upload(args)
    except ImportError:
        print('Установите зависимости: python -m pip install -r requirements.txt', file=sys.stderr)
        return 1
    except SetupError as error:
        print(str(error), file=sys.stderr)
        return 1
    except (ValueError, OSError):
        print('Ошибка настройки. Проверьте путь к файлам, OAuth-доступ и параметры команды. Секретные значения в журнал не выводятся.', file=sys.stderr)
        return 1
    except Exception:
        print('Google API отклонил запрос или соединение прервалось. Проверьте API, доступы приложения и сеть. Токены в журнал не выводятся.', file=sys.stderr)
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
