@echo off
setlocal
cd /d "%~dp0"
if not exist "client_secret.json" (
  echo Put your Google Desktop OAuth client JSON here as client_secret.json.
  echo Follow README_RU.md, then run this file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>nul
  if errorlevel 1 (
    python -m venv .venv
  ) else (
    py -3 -m venv .venv
  )
  if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" youtube.py authorize --client-secret client_secret.json
if errorlevel 1 goto failed
echo.
echo Connected. Follow step 4 in README_RU.md for cloud access.
echo Keep .secrets\token.json private. Do not send it in chat or upload it to GitHub.
pause
exit /b 0
:failed
echo Setup failed. See README_RU.md. No video was uploaded by this script.
pause
exit /b 1
