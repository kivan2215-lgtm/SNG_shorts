from pathlib import Path
import json,math,subprocess,hashlib
from functools import lru_cache
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent;src=p.parent/'short_003_chowchilla_v2'
GOLD='#ffd080';BLUE='#7ecfe1';TEXT='#edf1ef';RED='#ee9b7e'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
@lru_cache(maxsize=80)
def font(n):return ImageFont.truetype(FONT,n)
def label(d,xy,text,n=35,color=TEXT,maxw=950):
 while max(font(n).getlength(r) for r in text.split('\n'))>maxw:n-=1
 d.multiline_text(xy,text,font=font(n),fill=color,anchor='mm',align='center',spacing=11)
# Rendered 3D objects; diagram dimensions are explanatory, not asserted historical measurements.
model={k:Image.open(p/(k+'.png')).convert('RGBA') for k in ['ladder','trap','weight','roof','mattress','escape','dig']}
motion=[model['mattress']]+[(Image.open(p/f'lid_motion_{i:02d}.png').convert('RGBA') if (p/f'lid_motion_{i:02d}.png').exists() else model['escape']) for i in range(1,10)]+[model['escape']]
a=json.loads((p/'anchors.json').read_text())
def project(name):x,y,_=a[name];return (40+round(x*1000),220+round((1-y)*1000))
styles={
 'ladder':('Единственный вход — сверху','ЛЕСТНИЦА ВЕЛА В ЗАКОПАННЫЙ КУЗОВ',('lid','Вход через люк'),('ladder','Лестница внутри')),
 'trap':('Лестницу убрали. Люк перекрыли','26 ДЕТЕЙ И ВОДИТЕЛЬ ОКАЗАЛИСЬ В ЛОВУШКЕ',('lid','Единственный выход'),('trailer','Кузов под землёй')),
 'weight':('Почему люк не открывался','МЕТАЛЛИЧЕСКИЙ ЛИСТ И ДВА ТЯЖЁЛЫХ АККУМУЛЯТОРА',('weight','Два аккумулятора'),('lid','Лист придавил крышку')),
 'roof':('Крыша начала прогибаться','ЖДАТЬ СТАНОВИЛОСЬ ВСЁ ОПАСНЕЕ',('roof','Металл прогибался'),('trailer','Люди оставались внутри')),
 'mattress':('Матрасы помогли достать до люка','ШАГ 1 • ПОДНЯТЬСЯ ВЫШЕ',('lid','Нужно достать до крышки'),('mattress','Матрасы сложили стопкой')),
 'escape':('Крышку приподняли и подперли','ШАГ 2 • УДЕРЖАТЬ ПРОХОД ОТКРЫТЫМ',('wedge','Подпорка из дерева'),('lid','Крышку приподняли')),
 'dig':('Оставалось разгребать землю','ШАГ 3 • ОСВОБОДИТЬ ВЫХОД',('lid','Земля над люком'),('mattress','Подъём к проходу'))}
# Spacious typography with labels only for the two objects discussed in this shot.
def background(mode):
 im=Image.new('RGB',(1080,1420));d=ImageDraw.Draw(im)
 for y in range(1420):
  v=max(0,int(12*(1-abs(y-790)/800)));d.line((0,y,1080,y),fill=(10+v,19+v,28+v))
 label(d,(540,72),'КАК ЭТО БЫЛО УСТРОЕНО',27,BLUE)
 label(d,(540,153),styles[mode][0],51,TEXT)
 d.line((76,210,1004,210),fill='#42535f',width=2)
 # Soft halo beneath a 3D cutaway; model remains still, no shaking or pan/zoom.
 for r in range(350,0,-1):
  c=(20+int((350-r)*.016),34+int((350-r)*.02),44+int((350-r)*.025));d.ellipse((540-r,850-r*.55,540+r,850+r*.55),fill=c)
 label(d,(540,1250),styles[mode][1],31,GOLD)
 if mode in ['mattress','escape','dig']:
  active=['mattress','escape','dig'].index(mode)
  for i,tx in enumerate(['ДОБРАТЬСЯ','ПРИПОДНЯТЬ','РАЗГРЕСТИ']):
   x=72+i*324;d.rounded_rectangle((x,1300,x+288,1357),radius=16,fill='#3e514f' if i<=active else '#192a37',outline=GOLD if i==active else '#3c5260',width=2);label(d,(x+144,1328),str(i+1)+'  '+tx,24,GOLD if i==active else '#8ba1aa',maxw=270)
 label(d,(540,1400),'ПОЯСНЯЮЩАЯ 3D-СХЕМА • НЕ В МАСШТАБЕ',21,'#96aab3')
 return im
bg={k:background(k) for k in model}
def arrow(d,start,end,color=GOLD,progress=1):
 e=(start[0]+(end[0]-start[0])*progress,start[1]+(end[1]-start[1])*progress);d.line((*start,*e),fill=color,width=7)
 ang=math.atan2(end[1]-start[1],end[0]-start[0]);d.polygon([e,(e[0]-20*math.cos(ang-.5),e[1]-20*math.sin(ang-.5)),(e[0]-20*math.cos(ang+.5),e[1]-20*math.sin(ang+.5))],fill=color)
def panel(mode,t):
 im=bg[mode].copy();obj=model[mode]
 if mode=='escape':
  z=min(10,max(0,t/1.05*10));i=min(9,int(z));obj=Image.blend(motion[i],motion[i+1],z-i)
 # Alpha compositing preserves the subtle ground shadow and material shading.
 im.paste(obj,(40,220),obj);d=ImageDraw.Draw(im)
 for j,(key,text) in enumerate(styles[mode][2:]):
  pt=project(key);x,y=(80,315) if j==0 else (80,1144);w=min(700,max(410,round(font(31).getlength(text))+44));end=(x+w-25,y+32) if j==0 else (x+w-30,y-10)
  # Thin leader lines plus small animated ring make the discussed part easy to find.
  d.line((*pt,*end),fill=BLUE if j==0 else GOLD,width=3);rad=7+int(3*math.sin(min(t,1.3)*math.pi)**2);d.ellipse((pt[0]-rad,pt[1]-rad,pt[0]+rad,pt[1]+rad),outline=BLUE if j==0 else GOLD,width=3)
  d.rounded_rectangle((x,y-28,x+w,y+28),radius=14,fill='#142a38',outline='#526d7d',width=2);label(d,(x+w/2,y),text,31,TEXT,maxw=w-25)
 # Movement is instructional: effort direction, never camera motion.
 phase=.35+.65*min(1,t/.75)
 if mode in ['mattress','escape','dig']:
  pt=project('lid');arrow(d,(pt[0]+105,pt[1]+200),(pt[0]+105,pt[1]+65),GOLD,phase)
 if mode=='weight':
  pt=project('weight');arrow(d,(pt[0]+170,pt[1]-100),(pt[0]+170,pt[1]+15),RED,phase)
 if mode=='ladder':
  pt=project('ladder');arrow(d,(pt[0]-100,pt[1]-180),(pt[0]-100,pt[1]+30),BLUE,phase)
 if mode=='dig':
  pt=project('lid');arrow(d,(pt[0],pt[1]-60),(pt[0]-100,pt[1]-155),BLUE,phase);arrow(d,(pt[0]+15,pt[1]-60),(pt[0]+120,pt[1]-150),BLUE,phase)
 if mode=='dig':
  pt=project('lid');progress=min(1,t/1.2)
  for j in range(22):
   side=-1 if j%2 else 1;u=((j*37)%100)/100;v=((j*53)%100)/100
   x=pt[0]-48+u*96+side*progress*115;y=pt[1]-12-v*24-progress*(65+v*40)
   r=max(1,7*(1-.85*progress));d.ellipse((x-r,y-r,x+r,y+r),fill='#a07c52',outline='#d1b28b')
 return np.asarray(im)
plan=json.loads((src/'shot_timing.json').read_text());mapping={7:'ladder',9:'trap',10:'weight',11:'trap',13:'trap',15:'roof',17:'mattress',18:'escape',20:'dig'}
segments=[(v['start'],v['end'],mapping[i]) for i,v in enumerate(plan) if i in mapping]
(p/'animation_plan.json').write_text(json.dumps([dict(start=s,end=e,mode=m) for s,e,m in segments],indent=2))
if __name__=='__main__':
 # Preserve the entire already approved AAC stream bit-for-bit.
 cap=cv2.VideoCapture(str(src/'SNG_003_Chowchilla_PREVIEW_V2.mp4'));out=p/'SNG_003_Chowchilla_PREVIEW_V3.mp4'
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-i',str(src/'SNG_003_Chowchilla_PREVIEW_V2.mp4'),'-map','0:v:0','-map','1:a:0','-map_metadata','1','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','copy','-t','58.4','-movflags','+faststart',str(out)]
 assert all((p/f'lid_motion_{i:02d}.png').exists() for i in range(1,10))
 ff=subprocess.Popen(cmd,stdin=subprocess.PIPE);n=0;last_rgb=None;active=None;transition=None
 while True:
  ok,frame=cap.read()
  if not ok:break
  rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB);t=n/30
  matched=False
  for s,e,m in segments:
   if s<=t<e:
    matched=True
    if active!=s:
     transition=last_rgb[:1420].copy() if last_rgb is not None else rgb[:1420].copy();active=s
    newpanel=panel(m,t-s);alpha=min(1,(t-s)/.18)
    rgb[:1420]=newpanel
    if alpha<1:rgb[410:1110]=np.asarray(Image.blend(Image.fromarray(transition[410:1110]),Image.fromarray(newpanel[410:1110]),alpha))
    break
  if not matched:active=None
  last_rgb=rgb.copy()
  ff.stdin.write(rgb.tobytes());n+=1
  if n%300==0:print('Frame',n,flush=True)
 cap.release();ff.stdin.close();assert ff.wait()==0
 assert n==1752,n
 print('Written',out.name,out.stat().st_size,flush=True)
