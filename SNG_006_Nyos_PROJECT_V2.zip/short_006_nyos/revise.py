from pathlib import Path
p=Path(__file__).parent;s=(p/'build.py').read_text();a=s.index('def chart(stage):');b=s.index('\nscenes=',a)
s=s[:a]+'''def archive(file,title,credit):
 im,d=canvas(title);pic=ImageOps.exif_transpose(Image.open(p/file).convert('RGB'));pic.thumbnail((1020,1070),Image.Resampling.LANCZOS);im.paste(pic,((1080-pic.width)//2,800-pic.height//2));txt(d,(540,1360),credit,25,'#b7cbd0');return im

def chart(stage):
 im,d=canvas('НЕВИДИМАЯ ПРИЧИНА')
 # Distinct compartments and surface/topography rather than decorative boxes.
 sky='#18313f';d.polygon([(55,360),(400,480),(620,440),(1030,630),(1030,1320),(55,1320)],fill=sky)
 d.polygon([(55,480),(320,530),(530,540),(720,670),(1030,930),(1030,1320),(55,1320)],fill='#385945')
 d.polygon([(110,620),(410,620),(455,680),(620,680),(665,750),(110,750)],fill='#80b8bd')
 d.polygon([(130,750),(630,750),(610,1210),(150,1210)],fill='#124f6b')
 d.line((130,750,630,750),fill='#a6e3ea',width=6)
 txt(d,(370,565),'ОЗЕРО НИОС',38)
 d.polygon([(800,830),(1010,905),(1010,1190),(800,1100)],fill='#89755b')
 txt(d,(903,835),'ДОЛИНЫ',32)
 for y in range(935,1195,80):
  for x in range(235,570,95):d.ellipse((x,y,x+11,y+11),fill='#bbdee3')
 txt(d,(370,1145),'CO₂ В ГЛУБИНЕ',38,'#f3cd88')
 stage_labels=['1  ГАЗ НАКАПЛИВАЛСЯ ПОД ДАВЛЕНИЕМ','2  ВОДА ВЫСВОБОДИЛА CO₂','3  НЕВИДИМЫЙ ГАЗ ПОШЁЛ В ДОЛИНЫ']
 txt(d,(540,290),stage_labels[stage],34,'#ffd28a')
 if stage>=1:
  d.line((470,990,470,720),fill='#ffd28a',width=12);d.polygon([(470,688),(445,735),(495,735)],fill='#ffd28a')
  for i in range(5):d.ellipse((420+i*25,660-i*8,435+i*25,675-i*8),outline='#ffd28a',width=4)
 if stage>=2:
  # Amber dashed path is explanatory and does not imply visibly colored gas.
  pts=[(615,680),(700,720),(785,780),(860,845),(950,905)]
  for a,b in zip(pts,pts[1:]):d.line((*a,*b),fill='#ffd28a',width=10)
  d.polygon([(962,915),(930,910),(955,885)],fill='#ffd28a')
  txt(d,(790,1040),'CO₂ НЕВИДИМ',30,'#ffd28a')
 txt(d,(540,1390),'УСЛОВНАЯ СХЕМА • НЕ ТОЧНЫЙ МАРШРУТ ГАЗА',22,'#a4bcc6')
 return im
''' + s[b:]
a=s.index('scenes=');b=s.index('\n# Shift',a)
s=s[:a]+'''scenes=[
 (0,scene(0,'УТРО ПОСЛЕ КАТАСТРОФЫ')),
 (3,scene(1,'ДОМА СТОЯЛИ ЦЕЛЫМИ')),
 (6,scene(8,'НИ ПОЖАРА, НИ СЛЕДОВ НАПАДЕНИЯ')),
 (9,scene(2,'РАСТЕНИЯ ОСТАЛИСЬ НЕВРЕДИМЫ')),
 (12,archive('provided_1.jpg','КАМЕРУН • ОЗЕРО НИОС','ФОТО ИЗ МАТЕРИАЛОВ ЗАДАНИЯ • ДАТА НЕ ПОДТВЕРЖДЕНА')),
 (15,scene(4,'ГРОХОТ СО СТОРОНЫ ОЗЕРА')),
 (18,scene(5,'НОЧЬ. БЛИЗЛЕЖАЩИЕ ДЕРЕВНИ')),
 (21,scene(0,'ЛЮДИ ТЕРЯЛИ СОЗНАНИЕ')),
 (24,scene(1,'НЕКОТОРЫЕ ОЧНУЛИСЬ ПОЗЖЕ')),
 (27,archive('provided_2.jpg','ПОСЛЕ КАТАСТРОФЫ','ФОТО ИЗ МАТЕРИАЛОВ ЗАДАНИЯ • ДАТА НЕ ПОДТВЕРЖДЕНА')),
 (30,scene(8,'ПОСТРАДАЛО НЕСКОЛЬКО ПОСЕЛЕНИЙ')),
 (33,scene(2,'БОЛЕЕ 1700 ПОГИБШИХ')),
 (36,archive('nyos_smithsonian.jpg','РЕАЛЬНОЕ ФОТО ОЗЕРА НИОС','SMITHSONIAN GLOBAL VOLCANISM PROGRAM')),
 (39,scene(6,'УЧЁНЫЕ ИССЛЕДОВАЛИ ОЗЕРО')),
 (42,chart(0)),(47,chart(1)),(52,chart(2)),
 (57,archive('provided_3.jpg','ПОЗЖЕ ГАЗ ВЫВОДИЛИ ЧЕРЕЗ ТРУБЫ','ФОТО ИЗ МАТЕРИАЛОВ ЗАДАНИЯ • ДАТА НЕ ПОДТВЕРЖДЕНА')),
 (60,archive('nyos_smithsonian.jpg','ИСТОЧНИКОМ БЫЛО ОЗЕРО','SMITHSONIAN GLOBAL VOLCANISM PROGRAM'))]
''' + s[b:]
(p/'build.py').write_text(s)
