import subprocess,json,hashlib
from pathlib import Path
p=Path(__file__).parent;v=p/'SNG_005_Okene_PREVIEW_V2.mp4'
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(v)]))
a=next(s for s in info['streams'] if s['codec_type']=='video');b=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (a['width'],a['height'],a['r_frame_rate'],a['codec_name'],a['pix_fmt'])==(1080,1920,'30/1','h264','yuv420p')
assert abs(float(a['duration'])-float(info['format']['duration']))<.05
assert int(a['nb_frames'])==round(float(a['duration'])*30)
assert b['codec_name']=='aac' and b['channels']==2
assert 65<float(info['format']['duration'])<76
r=subprocess.run(['ffmpeg','-v','info','-i',str(v),'-vf','blackdetect=d=0.12:pix_th=0.05','-af','volumedetect','-f','null','-'],capture_output=True,text=True);assert r.returncode==0;assert 'black_start:' not in r.stderr
(p/'decode.log').write_text(r.stderr)
report={'duration':float(info['format']['duration']),'frames':a.get('nb_frames'),'decode':'passed','black_intervals':0,'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'human_listening':'pending','archive_photo':'missing_reuse_permission','visual_style':'static labeled reconstructions and schematic'}
(p/'qc.json').write_text(json.dumps(report,indent=2));print(report)
