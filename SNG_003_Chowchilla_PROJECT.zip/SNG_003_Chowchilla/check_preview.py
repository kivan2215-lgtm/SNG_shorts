from pathlib import Path
import subprocess,json,re,hashlib
p=Path(__file__).parent;v=p/'SNG_003_Chowchilla_PREVIEW.mp4'
x=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,pix_fmt,nb_frames,r_frame_rate,sample_rate,channels:format=duration,size','-of','json',str(v)]))
assert 57<=float(x['format']['duration'])<=65
video,audio=x['streams'][:2]
assert (video['width'],video['height'],video['r_frame_rate'],video['codec_name'],video['pix_fmt'])==(1080,1920,'30/1','h264','yuv420p')
assert audio['sample_rate']=='48000' and audio['channels']==2 and audio['codec_name']=='aac'
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-vf','blackdetect=d=0.1:pix_th=0.025:pic_th=0.98','-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True)
assert r.returncode==0 and 'black_start:' not in r.stderr
loud=json.loads(re.search(r'\{\s*"input_i".*?\}',r.stderr,re.S).group())
assert -18<float(loud['input_i'])<-14 and float(loud['input_tp'])<-.5
srt=(p/'subtitles.srt').read_text()
for block in srt.strip().split('\n\n'):
 lines=block.splitlines();plain=re.sub(r'<[^>]*>|\{[^}]*\}', '', ' '.join(lines[2:]));count=len(plain.split());assert 2<=count<=5,(count,block)
report={'media':x,'full_decode_ok':True,'no_black_intervals':True,'loudness':loud,'voice':'ru-RU-DmitryNeural','synthesis_rate':'+18%','native_russian_voice_same_as_approved_episode_1':True,'distinct_archival_photos':5,'rights_and_frames_reviewed':True,'subtitle_word_gate':'all cues 2 to 5 words','asr_check':'asr_check.json','human_pronunciation_review':'pending user; automated ASR cannot verify stress','sha256':hashlib.sha256(v.read_bytes()).hexdigest()}
(p/'qc_preview.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
