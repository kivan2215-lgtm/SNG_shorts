from PIL import Image,ImageDraw,ImageFont,ImageFilter
from pathlib import Path
import math,random
p=Path(__file__).parent
GOLD='#ffd18a';BLUE='#91e0e7';WHITE='#f0eee2';MUTED='#a7bdbe'
def F(n):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',n)
def label(d,xy,t,n=35,c=WHITE,w=970):
 while max(F(n).getlength(s) for s in t.split('\n'))>w:n-=1
 d.multiline_text(xy,t,font=F(n),fill=c,anchor='mm',align='center',spacing=12)
def canvas(title):
 im=Image.new('RGB',(1080,1920),'#0d2427');d=ImageDraw.Draw(im)
 for y in range(1400):d.line((0,y,1080,y),fill=(12+int(y/180),30+int(y/100),33+int(y/100)))
 label(d,(540,110),title,52);return im,d
def arrow(d,a,b,c=GOLD,w=7):
 d.line((*a,*b),fill=c,width=w);ang=math.atan2(b[1]-a[1],b[0]-a[0]);d.polygon([b,(b[0]-23*math.cos(ang-.55),b[1]-23*math.sin(ang-.55)),(b[0]-23*math.cos(ang+.55),b[1]-23*math.sin(ang+.55))],fill=c)
def water(title,stage=0):
 im,d=canvas(title);rnd=random.Random(4)
 # Relief-like watershed, explicitly a conceptual landscape rather than a real route.
 d.polygon([(60,410),(820,280),(1030,890),(270,1120)],fill='#153f3b',outline='#476b58')
 for j in range(150):
  x=rnd.randint(100,950);y=rnd.randint(380,1060);r=rnd.randint(14,28)
  if 340<x<650:continue
  d.ellipse((x-r,y-r*.7,x+r,y+r*.7),fill=rnd.choice(['#235548','#2e6050','#356950']),outline='#3d745c')
 # A small stream actually joins the wider river: continuity is the point of the graphic.
 stream=[(350+int(45*math.sin(j*.16)),395+j*7) for j in range(55)]
 join=stream[-1];river=[(join[0]+int(j*4+32*math.sin(j*.13)),join[1]+j*6) for j in range(60)]
 d.line(river,fill='#183f46',width=112);d.line(river,fill='#387a89',width=90);d.line(river,fill='#75c5cc',width=7)
 d.line(stream,fill='#173c41',width=40);d.line(stream,fill=BLUE if stage==0 else '#5bb1bc',width=23)
 for i in [15,35]:arrow(d,stream[i],stream[i+6],GOLD if stage==0 else '#c1d9d4',5)
 for i in [15,39]:arrow(d,river[i],river[i+6],GOLD if stage>=1 else '#8bb9bc',6)
 for idx,(xy,t) in enumerate([((690,420),'1  РУЧЕЙ'),((720,760),'2  РЕКА'),((590,1140),'3  ВОЗМОЖНЫЕ ПОСЕЛЕНИЯ')]):
  d.rounded_rectangle((xy[0]-190,xy[1]-42,xy[0]+190,xy[1]+42),radius=18,fill='#183e43',outline=GOLD if idx==stage else '#719592',width=3)
  label(d,xy,t,29,GOLD if idx==stage else WHITE,w=360)
 # Possibility, not a claim that a settlement existed at a recovered coordinate.
 for x,y in [(800,1000),(875,1040)]:
  d.polygon([(x,y),(x+34,y-26),(x+68,y)],fill='#c09b67');d.rectangle((x+5,y,x+62,y+39),fill='#876a4a');d.rectangle((x+28,y+17,x+43,y+39),fill='#263a32')
 expl=['НЕ ТЕРЯТЬ РУЧЕЙ ИЗ ВИДУ','СЛЕДОВАТЬ ВНИЗ ПО ТЕЧЕНИЮ','У РЕКИ МОГУТ ОКАЗАТЬСЯ ЛЮДИ'][stage]
 label(d,(540,1260),expl,33,GOLD)
 label(d,(540,1365),'СОВЕТ ЕЁ ОТЦА • НЕ ТОЧНАЯ КАРТА МАРШРУТА',23,MUTED)
 return im

def fall(title,kind=0):
 im,d=canvas(title)
 cloud=Image.open(p/'recon.png').convert('RGB').crop((515,3,1021,503)).resize((1080,1060))
 im.paste(cloud,(0,230));shade=Image.new('RGBA',im.size,(0,0,0,0));sd=ImageDraw.Draw(shade);sd.rectangle((35,290,410,1200),fill=(8,28,39,210));im=Image.alpha_composite(im.convert('RGBA'),shade).convert('RGB');d=ImageDraw.Draw(im)
 d.line((170,415,170,1050),fill=BLUE,width=9)
 for y in range(415,1050,80):d.line((150,y,192,y),fill=BLUE,width=4)
 arrow(d,(280,500),(280,900),GOLD,9)
 label(d,(227,352),'≈ 3000 М',48,GOLD,w=355)
 label(d,(222,1070),'БЕЗ\nПАРАШЮТА' if kind==0 else 'ПРИСТЁГНУТА\nК КРЕСЛУ',31,w=330)
 label(d,(540,1360),'ПОЯСНЯЮЩАЯ ВИЗУАЛИЗАЦИЯ • РЕКОНСТРУКЦИЯ',23,MUTED)
 return im
