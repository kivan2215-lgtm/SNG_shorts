from pathlib import Path
import json,subprocess,wave,math,unicodedata,re,os
import numpy as np
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).parent;sr=48000
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/'v0.mp3'),'-ar',str(sr),'-ac','1','-f','s16le','-']);a=np.frombuffer(raw,dtype=np.int16)
words=json.loads((p/'boundaries.json').read_text());cuts=[]
for x,y in zip(words,words[1:]):
 end=(x['offset']+x['duration'])/1e7;start=y['offset']/1e7
 if start-end>.7:cuts.append((end+.16,start-.16))
parts=[];pos=0
for x,y in cuts:parts.append(a[pos:round(x*sr)]);pos=round(y*sr)
parts.append(a[pos:]);a=np.concatenate(parts)
for w in words:
 t=w['offset']/1e7;w['start']=t-sum(y-x for x,y in cuts if y<=t);w['end']=w['start']+w['duration']/1e7
 w['text']=unicodedata.normalize('NFC',unicodedata.normalize('NFD',w['text']).replace('\u0301',''))
duration=math.ceil((words[-1]['end']+.30)*30)/30
assert 60<=duration<=75,duration
print('Duration',duration,flush=True)
a=a[:round(duration*sr)];a=np.pad(a,(0,max(0,round(duration*sr)-len(a))))
def at(phrase):
 tokens=phrase.lower().replace('ё','е').split();norm=[w['text'].lower().replace('ё','е').strip('.,!?:;—') for w in words]
 for j in range(len(norm)-len(tokens)+1):
  if norm[j:j+len(tokens)]==tokens:return words[j]['start']
 raise ValueError(phrase)
# Original music and effects: tension before escape, restrained relief afterwards.
t=np.arange(len(a))/sr;rng=np.random.default_rng(76);escape=at('после одиннадцати')
score=(np.sin(2*np.pi*49*t)+.4*np.sin(2*np.pi*73.416*t))*.0028
pulse=(np.sin(2*np.pi*(.75*t+.008*t*t))*.5+.5)**12
score+=pulse*np.sin(2*np.pi*98*t)*.002
score[t>=escape]=(.002*np.sin(2*np.pi*146.83*t[t>=escape])+.0015*np.sin(2*np.pi*220*t[t>=escape]))
for when in [.12,at('ударила молния')]:
 n=round(.25*sr);u=np.arange(n)/sr;fx=(rng.normal(0,1,n)*.01+np.sin(2*np.pi*95*u)*.02)*np.exp(-u*15);start=round(when*sr);score[start:start+n]+=fx
score[(t>at('и выжила')) & (t<at('двадцать четвёртого'))]=0
# Low thunder roll, no loud clipping or strobe.
score+=rng.normal(0,1,len(a))*.0005
mix=np.clip(a.astype(float)/32768+score,-.95,.95)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype(np.int16).tobytes())

font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def F(n):return ImageFont.truetype(font,n)
recon=Image.open(p/'recon.png').convert('RGB');W,H=recon.size
panels=[recon.crop(box) for box in [(3,3,509,503),(515,3,1021,503),(3,512,509,1009),(515,512,1021,1009),(3,1017,509,1533),(515,1017,1021,1533)]]
photos=[Image.open(p/f'photo{i}.jpg').convert('RGB') for i in range(2)]
def frame(title,im,kind,caption=''):
 bg=Image.new('RGB',(1080,1920),'#0d1d20');d=ImageDraw.Draw(bg)
 size=54
 while max(F(size).getlength(t) for t in title.split('\n'))>970:size-=1
 d.multiline_text((540,116),title,font=F(size),fill='#f2eee3',anchor='mm',align='center',spacing=12)
 if kind=='recon':thumb=im.resize((1080,1080),Image.Resampling.LANCZOS);xy=(0,220)
 else:
  factor=min(1000/im.width,1060/im.height);thumb=im.resize((round(im.width*factor),round(im.height*factor)),Image.Resampling.LANCZOS);xy=((1080-thumb.width)//2,760-thumb.height//2)
 bg.paste(thumb,xy)
 d.text((540,1355),'РЕКОНСТРУКЦИЯ' if kind=='recon' else caption,font=F(25),fill='#d0c9a9',anchor='mm')
 return bg

def water(title):
 bg=Image.new('RGB',(1080,1920),'#10292c');d=ImageDraw.Draw(bg);d.text((540,120),title,font=F(53),fill='#f3eedc',anchor='mm')
 import math
 pts=[(280+int(95*math.sin(j*.15)),380+j*9) for j in range(82)]
 d.line(pts,fill='#255e64',width=105);d.line(pts,fill='#83d6d7',width=14)
 for y,text in [(430,'РУЧЕЙ'),(740,'РЕКА'),(1090,'ВОЗМОЖНЫЕ ПОСЕЛЕНИЯ')]:
  d.rounded_rectangle((470,y-55,1010,y+55),radius=20,fill='#1e4044',outline='#76bdc1',width=3);d.text((740,y),text,font=F(31),fill='#f3d18c',anchor='mm')
 for y in [540,810]:d.line((375,y,420,y+100),fill='#f3d18c',width=8);d.polygon([(420,y+100),(396,y+75),(432,y+71)],fill='#f3d18c')
 d.text((540,1355),'СХЕМА ПРИНЦИПА • НЕ КАРТА ЕЁ МАРШРУТА',font=F(24),fill='#aac3c5',anchor='mm');return bg

from diagrams import water,fall
more=Image.open(p/'more.png').convert('RGB');mw,mh=more.size
panels += [more.crop((c*mw//3+3,r*mh//3+3,(c+1)*mw//3-3,(r+1)*mh//3-3)) for r in range(3) for c in range(3)]
scene=[]
def add(t,panel,title,kind='recon'):
 if kind=='diagram':im=water(title,panel)
 elif kind=='fall':im=fall(title,panel)
 else:im=frame(title,panels[panel] if kind=='recon' else photos[panel],kind,'ЮЛИАНА КЁПКЕ • ФОТО 2019 ГОДА')
 scene.append(dict(start=t,image=im,kind=kind,title=title,asset=panel))
add(0,0,'САМОЛЁТ РАЗВАЛИЛСЯ В НЕБЕ')
add(at('семнадцатилетняя'),1,'ЕЙ БЫЛО 17 ЛЕТ')
add(at('с высоты'),0,'ПАДЕНИЕ С ВЫСОТЫ ≈ 3000 М','fall')
add(at('без парашюта'),1,'БЕЗ ПАРАШЮТА','fall')
add(at('и выжила'),8,'НО ОНА ВЫЖИЛА')
add(at('двадцать четвёртого'),6,'ПЕРУ • 24 ДЕКАБРЯ 1971')
add(at('юлиана кёпке'),6,'ЮЛИАНА КЁПКЕ • 17 ЛЕТ')
add(at('ударила молния'),7,'УДАР МОЛНИИ')
add(at('она помнила'),1,'ОНА ОСТАВАЛАСЬ ПРИСТЁГНУТОЙ')
add(at('а очнулась'),8,'ОЧНУЛАСЬ УЖЕ НА ЗЕМЛЕ')
add(at('она потеряла'),9,'ПОТЕРЯННЫЕ ОЧКИ')
add(at('один глаз'),9,'ТРАВМЫ ПОСЛЕ ПАДЕНИЯ')
add(at('но это'),2,'НО ЭТО БЫЛО ТОЛЬКО НАЧАЛО')
add(at('еды почти'),12,'ЕДЫ ПОЧТИ НЕ БЫЛО')
add(at('а поисковые'),11,'ПОИСКИ НАД ДЖУНГЛЯМИ')
add(at('сквозь густые'),10,'КРОНЫ СКРЫВАЛИ ЕЁ ОТ СПАСАТЕЛЕЙ')
add(at('тогда юлиана'),0,'ОНА ВСПОМНИЛА СОВЕТ ОТЦА','diagram')
add(at('если потеряешься'),0,'ДЕРЖАТЬСЯ ТЕКУЩЕЙ ВОДЫ','diagram')
add(at('ручей выведет'),1,'РУЧЕЙ ВПАДАЕТ В РЕКУ','diagram')
add(at('а у реки'),2,'У РЕКИ МОГУТ БЫТЬ ЛЮДИ','diagram')
add(at('она нашла ручей'),3,'ОНА ПОШЛА ВДОЛЬ РУЧЬЯ')
add(at('надеясь'),13,'РУЧЕЙ СТАНОВИЛСЯ ШИРЕ')
add(at('дни шли'),4,'ДНИ ШЛИ. СИЛЫ ЗАКАНЧИВАЛИСЬ')
add(at('но она продолжала'),13,'ОНА ПРОДОЛЖАЛА ИДТИ')
add(at('наконец'),5,'ХИЖИНА СРЕДИ ДЕРЕВЬЕВ')
add(at('а позднее'),14,'ТУДА ВЕРНУЛИСЬ ЛЕСОРУБЫ')
add(at('после одиннадцати'),0,'ЮЛИАНА БЫЛА СПАСЕНА','photo')
add(at('из девяноста'),1,'92 ЧЕЛОВЕКА НА БОРТУ','photo')
add(at('единственной'),0,'ЕДИНСТВЕННАЯ ВЫЖИВШАЯ','photo')
scene.sort(key=lambda s:s['start']);expanded=[]
for i,s in enumerate(scene):
 end=scene[i+1]['start'] if i+1<len(scene) else duration
 n=math.ceil((end-s['start'])/3)
 for j in range(n):
  v=dict(s,start=s['start']+(end-s['start'])*j/n)
  if j>0 and s['kind']=='recon':
   im=s['image'].copy();detail=im.crop((120,340,960,1180)).resize((1080,1080),Image.Resampling.LANCZOS);im.paste(detail,(0,220));v['image']=im;v['detail_cut']=True
  expanded.append(v)
scene=expanded
(p/'shot_timing.json').write_text(json.dumps([{k:v for k,v in s.items() if k!='image'} for s in scene],ensure_ascii=False,indent=2))
# Sentence-aware subtitles: keep two to five words, never carry the next sentence early.
text=(p/'narration.txt').read_text();sentences=re.split(r'[.!?]+',text);sizes=[];pending=0
for sentence in sentences:
 n=len(re.findall(r'[А-Яа-яЁё]+(?:-[А-Яа-яЁё]+)?',sentence));pending+=n
 if pending>=2:sizes.append(pending);pending=0
if pending:sizes[-1]+=pending
assert sum(sizes)==len(words),(sum(sizes),len(words))
groups=[];cursor=0
for n in sizes:
 count=math.ceil(n/5);q,r=divmod(n,count)
 for j in range(count):k=q+(j<r);groups.append(words[cursor:cursor+k]);cursor+=k
assert all(2<=len(g)<=5 for g in groups)
def stamp(t):
 n=round(t*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'
ass='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: S,DejaVu Sans,56,&H00FFFFFF,&H000000FF,&H00101010,&H00101010,-1,0,0,0,100,100,0,0,1,4,1,5,90,170,0,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
for g in groups:
 rows=[];row=[]
 for w in g:
  token=w['text'].upper()
  if row and F(56).getlength(' '.join(row+[token]))>850:rows.append(' '.join(row));row=[]
  row.append(token)
 if row:rows.append(' '.join(row))
 txt=r'\N'.join(rows)
 for key in ['ВЫЖИЛА','ПАРАШЮТА','ВОДЫ','ОДНА','СПАСЕНА','ЕДИНСТВЕННОЙ']:txt=txt.replace(key,r'{\c&H70C8F4&}'+key+r'{\c&HFFFFFF&}')
 ass+=f'Dialogue: 0,{stamp(g[0]["start"])},{stamp(g[-1]["end"])},S,,0,0,0,,{{\\pos(500,1510)}}{txt}\n'
(p/'subtitles.ass').write_text(ass);(p/'words.json').write_text(json.dumps(words,ensure_ascii=False))

import cv2
# Mild, smooth camera movement inside illustrative pictures only. Text and real photographs stay fixed.
N=round(duration*30);silent=p/'picture.mp4'
ff=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',str(silent)],stdin=subprocess.PIPE)
idx=0
for n in range(N):
 t=n/30
 while idx+1<len(scene) and t>=scene[idx+1]['start']:idx+=1
 s=scene[idx];im=s['image'].copy()
 ff.stdin.write(im.tobytes())
 if n%450==0:print('Frame',n,flush=True)
ff.stdin.close();assert ff.wait()==0
out=p/'SNG_004_Juliane_Koepcke_PREVIEW_V2.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(silent),'-i',str(p/'mix.wav'),'-vf',f'ass={p/"subtitles.ass"}','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-t',str(duration),'-metadata','comment=Portrait photographs: Cancilleria del Peru, 3 April 2019, CC BY-SA 2.0. Full credits https://github.com/kivan2215-lgtm/SNG_shorts/blob/main/production/SNG_004_SOURCES.md','-movflags','+faststart',str(out)],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p/'subtitles.ass'),str(p/'subtitles.srt')],check=True)
print('Preview complete',out.stat().st_size,flush=True)
