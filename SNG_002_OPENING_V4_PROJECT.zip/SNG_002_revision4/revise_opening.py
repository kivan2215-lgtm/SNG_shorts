import asyncio,json,os,ssl,subprocess,wave
from pathlib import Path
import numpy as np
import edge_tts
p=Path(__file__).parent;previous=p.parent/'revision3'
opening='Этот бак протекал, а его просто покрасили. Январь тысяча девятьсот девятнадцатого года. У набережной Бо́стона стоит огромный стальной бак. В нём па́тока — густой сладкий сироп. Высота бака — пятнадцать метров, диаметр — двадцать семь.'
ca=os.environ.get('SSL_CERT_FILE') or os.environ.get('CODEX_PROXY_CERT');original=ssl.create_default_context
def context(*a,**kw):
 c=original(*a,**kw)
 if ca:c.load_verify_locations(cafile=ca)
 return c
ssl.create_default_context=context
async def synth():
 boundaries=[]
 c=edge_tts.Communicate(opening,'ru-RU-DmitryNeural',rate='+18%',boundary='WordBoundary',proxy=os.environ.get('HTTPS_PROXY'))
 with (p/'opening.mp3').open('wb') as f:
  async for m in c.stream():
   if m['type']=='audio':f.write(m['data'])
   else:boundaries.append(m)
 return boundaries
new=asyncio.run(synth());old=json.loads((previous/'boundaries.json').read_text())
# Preserve every original word and sample after the second paragraph.
indices=[i for i in range(len(old)-1) if old[i]['text'].lower()=='бак' and old[i+1]['text'].lower()=='протекал']
assert len(indices)==2
idx=indices[1];oldstart=old[idx]['offset']/1e7-.04
sr=48000
def pcm(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-ar',str(sr),'-ac','1','-f','s16le','-']),dtype=np.int16).copy()
a=pcm(p/'opening.mp3');b=pcm(previous/'v0.mp3')
# Short clean inter-paragraph gap; no global time stretching or voice replacement.
newend=(new[-1]['offset']+new[-1]['duration'])/1e7+.10
a=a[:round(newend*sr)];b=b[round(oldstart*sr):]
fade=round(.008*sr);a[-fade:]=(a[-fade:]*np.linspace(1,0,fade)).astype(np.int16);b[:fade]=(b[:fade]*np.linspace(0,1,fade)).astype(np.int16)
gap=np.zeros(round(.08*sr),dtype=np.int16);joined=np.concatenate([a,gap,b]);shift=(len(a)+len(gap))/sr-oldstart
for w in old[idx:]:w['offset']+=round(shift*1e7)
with wave.open(str(p/'voice_revised.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(joined.tobytes())
(p/'boundaries.json').write_text(json.dumps(new+old[idx:],ensure_ascii=False))
(p/'opening_text.txt').write_text(opening)
(p/'tts_script.txt').write_text(opening+'\n'+(previous/'tts_script.txt').read_text().split('\n',2)[2])
(p/'opening_revision.json').write_text(json.dumps({'voice':'ru-RU-DmitryNeural','opening_rate':'+18%','continuation_rate':'+8%','original_continuation_pcm_preserved':True,'join_gap_seconds':.08,'old_tail_start':oldstart,'new_opening_end':newend,'shift_seconds':shift},indent=2))
print('Opening end',newend,'tail shift',shift,flush=True)
