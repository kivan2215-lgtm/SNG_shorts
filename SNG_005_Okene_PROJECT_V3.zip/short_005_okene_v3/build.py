from pathlib import Path
import json,subprocess,math,wave,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageOps
p=Path(__file__).parent
words=json.loads((p/'boundaries.json').read_text());words=[w for w in words if w['type']=='WordBoundary']
dur=math.ceil(float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p/'v0.mp3')]))*30)/30
print('DURATION',dur,flush=True)
def at(word):
 return next(w['offset']/1e7 for w in words if w['text'].lower().strip('.,:;!?')==word.lower())
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def text(d,xy,s,size=48,col='#f4f0df',width=930):
 while max(ImageFont.truetype(font,size).getlength(t) for t in s.split('\n'))>width:size-=1
 d.multiline_text(xy,s,font=ImageFont.truetype(font,size),fill=col,anchor='mm',align='center',spacing=18)
grid=Image.open(p/'recon.png').convert('RGB');W,H=grid.size
panels=[grid.crop((c*W//3+4,y0,(c+1)*W//3-4,y1)) for y0,y1 in [(3,274),(283,611),(622,921),(933,1251)] for c in range(3)]
def card(i,title):
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im)
 pic=panels[i].copy();pic.thumbnail((1080,1080));scale=min(1080/pic.width,1080/pic.height);pic=pic.resize((round(pic.width*scale),round(pic.height*scale)),Image.Resampling.LANCZOS);im.paste(pic,((1080-pic.width)//2,760-pic.height//2));text(d,(540,120),title,48);text(d,(850,275),'Реконструкция',20,'#c3cdd0',width=340);return im

def diagram():
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im)
 text(d,(540,115),'КАК ОН ОСТАЛСЯ ЖИВ',49)
 text(d,(540,205),'Вода заполнила не всё помещение',31,'#a7c7d2')
 # A schematic compartment section, explicitly not a vessel blueprint.
 d.rounded_rectangle((190,420,965,1120),radius=70,fill='#183747',outline='#b0c6cc',width=10)
 d.rounded_rectangle((205,435,950,780),radius=48,fill='#665b36')
 d.rectangle((205,750,950,1090),fill='#155e79')
 for x in range(205,880,45): d.arc((x,735,x+70,775),0,180,fill='#6dcce1',width=4)
 # Person's head stays in the air, body below surface.
 d.ellipse((415,650,485,720),fill='#ffd690');d.line((450,721,450,880),fill='#ffd690',width=22)
 d.line((450,760,380,810),fill='#ffd690',width=16);d.line((450,760,520,810),fill='#ffd690',width=16)
 d.line((450,880,405,955),fill='#ffd690',width=16);d.line((450,880,495,955),fill='#ffd690',width=16)
 text(d,(580,505),'ВОЗДУХ',52,'#ffe0a2');text(d,(580,575),'Сохранился над водой',29)
 text(d,(730,940),'ВОДА',48,'#9ee4f1')
 # No depth ruler on compartment: 30 m refers to vessel depth.
 d.line((205,455,950,455),fill='#a8bfc6',width=3)
 text(d,(540,1220),'СУДНО НА ГЛУБИНЕ ≈ 30 М',42,'#ffd28a')
 text(d,(540,1320),'Условный разрез помещения',26,'#a7c7d2')
 text(d,(540,1370),'Не чертёж Jascon-4 • размеры условны',23,'#a7c7d2')
 return im

def endcard():
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im);text(d,(540,370),'JASCON-4',80,'#ffd28a');text(d,(540,500),'НИГЕРИЯ • 26 МАЯ 2013',32)
 text(d,(540,760),'1 ВЫЖИВШИЙ',65);text(d,(540,890),'11 ПОГИБШИХ',50,'#9bb4bb');text(d,(540,1150),'Обнаружение записано\nкамерой водолаза',39);return im
scenes=[(0,card(0,'ОН ИСКАЛ ПОГИБШИХ')),(at('Нигерия'),card(1,'НИГЕРИЯ • МАЙ 2013')),(at('затонул'),card(2,'ОКОЛО 30 МЕТРОВ ПОД ВОДОЙ')),(at('борту'),card(3,'12 ЧЕЛОВЕК НА БОРТУ')),(at('Корабельный'),card(4,'ХАРРИСОН ОКЕНЕ • ПОВАР')),(at('воздушном'),diagram()),(at('Вокруг'),card(5,'ТЕМНОТА И ХОЛОД')),(at('сутки'),card(6,'24 ЧАСА')),(at('вторые'),card(7,'48 ЧАСОВ')),(at('Спустя'),card(8,'ОКОЛО 60 ЧАСОВ')),(at('повар'),card(9,'ОН ПРОТЯНУЛ РУКУ')),(at('нашли'),card(10,'ЕГО НАШЛИ ЖИВЫМ')),(at('декомпрессия'),card(11,'СПАСЕНИЕ ПРОДОЛЖАЛОСЬ')),(at('единственным'),endcard())]
# 'повар' occurs first in introduction; use last occurrence for discovery.
scenes[10]=(max(w['offset']/1e7 for w in words if w['text'].lower().strip('.,')=='повар'),scenes[10][1])
def archive(name,title,date):
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im);pic=ImageOps.exif_transpose(Image.open(p/(name+'.jpg'))).convert('RGB');pic.thumbnail((970,1080),Image.Resampling.LANCZOS);im.paste(pic,((1080-pic.width)//2,770-pic.height//2));text(d,(540,110),title,44);text(d,(540,1325),date,27,'#ffd28a');text(d,(540,1380),'Пример оборудования • не спасение Окене',24,'#a7c7d2');return im
scenes=[s for s in scenes if abs(s[0]-at('декомпрессия'))>.01]
scenes.append((48.896336000000026,archive('bell','ВОДОЛАЗНАЯ КАПСУЛА','АРХИВ • АТЛАНТИКА, 2001 • U.S. NAVY')))
scenes.append((51.63633600000003,archive('chamber','СИСТЕМА ДЕКОМПРЕССИИ','АРХИВ • SEALAB III, 1968–1969 • U.S. NAVY')))
extra=Image.open(p/'extra.png').convert('RGB');ew,eh=extra.size
for j,start in enumerate([2.5, 4.37575, 6.87575, 31.942669000000002, 41.06429400000001]):
 tile=extra.crop(((j%2)*ew//2+4,(j//2)*eh//3+4,(j%2+1)*ew//2-4,(j//2+1)*eh//3-4))
 im=Image.new('RGB',(1080,1920),'#091b25');d=ImageDraw.Draw(im)
 scale=min(1080/tile.width,1100/tile.height);tile=tile.resize((round(tile.width*scale),round(tile.height*scale)),Image.Resampling.LANCZOS);im.paste(tile,((1080-tile.width)//2,760-tile.height//2))
 text(d,(540,120),['ПОИСК В ТЕМНОТЕ','ЛУЧ ФОНАРЯ','НЕОЖИДАННОЕ ДВИЖЕНИЕ','ВЫХОД ЗАТОПЛЕН','ОН ПРОТЯНУЛ РУКУ'][j],44)
 text(d,(850,275),'Реконструкция',20,'#c3cdd0',width=340);scenes.append((start,im))
scenes.append((47.49633600000003,archive('interior','ВНУТРИ ВОДОЛАЗНОГО КОЛОКОЛА','PETER SOUTHWOOD • 2015 • CC BY-SA 4.0')))
scenes.append((38.764294000000014,archive('umbilical','ШЛАНГИ И СВЯЗЬ С ПОВЕРХНОСТЬЮ','PETER SOUTHWOOD • 2015 • CC BY-SA 4.0')))
scenes.sort(key=lambda x:x[0]);manifest=[];plan=[]
for i,(start,im) in enumerate(scenes):
 end=scenes[i+1][0] if i+1<len(scenes) else dur;f=p/f'card{i:02}.png';im.save(f);manifest.append(f"file '{f}'\noption framerate 30\nduration {end-start:.8f}\n");plan.append({'start':start,'end':end,'file':f.name})
manifest.append(f"file '{f}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest));(p/'shot_timing.json').write_text(json.dumps(plan,indent=2))
header=(p.parent/'short_004_juliane_v2/subtitles.ass').read_text().split('Dialogue:')[0]
def stamp(t):
 h=int(t//3600);m=int(t//60)%60;s=t%60;return f'{h}:{m:02}:{s:05.2f}'
lines=[];srt=[]
for i in range(0,len(words),4):
 g=words[i:i+4];a=g[0]['offset']/1e7;b=(words[i+4]['offset']/1e7 if i+4<len(words) else dur)
 ts=[w['text'].upper() for w in g];label=' '.join(ts[:2])+('\\N'+' '.join(ts[2:]) if len(ts)>2 else '')
 for kw in ['ТЕМНОТА','ВОЗДУХА','ЖИВОГО','РУКУ','ДЕКОМПРЕССИЯ','ВЫЖИВШИМ']:
  label=label.replace(kw,'{\\c&H8AD2FF&}'+kw+'{\\c&HFFFFFF&}')
 lines.append(f'Dialogue: 0,{stamp(a)},{stamp(b)},S,,0,0,0,,{{\\pos(500,1510)}}{label}\n')
 srt.append(f'{len(srt)+1}\n'+stamp(a).replace('.',',')+' --> '+stamp(b).replace('.',',')+'\n'+' '.join(ts)+'\n\n')
(p/'subtitles.ass').write_text(header+''.join(lines));(p/'subtitles.srt').write_text(''.join(srt))
# Original restrained ambient score and effects, generated locally; no borrowed recordings.
subprocess.run(['ffmpeg','-y','-v','error','-i',str(p/'v0.mp3'),'-ar','48000','-ac','1',str(p/'voice.wav')],check=True)
with wave.open(str(p/'voice.wav')) as w: voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
n=round(dur*48000);t=np.arange(n)/48000;v=np.pad(voice,(0,max(0,n-len(voice))))[:n];rng=np.random.default_rng(5)
# Original minor-key score, soft pulses and slowly changing harmony.
root=np.choose((t//8).astype(int)%4,[55.,51.913,48.999,51.913])
phase=2*np.pi*np.cumsum(root)/48000
pulse=(.5+.5*np.sin(2*np.pi*.72*t))**6
bed=.012*np.sin(phase)+.007*np.sin(phase*1.5)+.005*np.sin(phase*2.3784)
bed+=.006*pulse*np.sin(phase*4)+.001*rng.normal(size=n)
# Duck the score under narration using a 100 ms moving RMS envelope.
env=np.sqrt(np.convolve(v[::480]**2,np.ones(10)/10,mode='same'))
duck=np.interp(t,np.arange(len(env))*.01,np.clip(1-env*8,.38,1))
bed*=duck

rescue=at('нашли');bed*=np.where(t<rescue,1,.3);bed*=np.minimum(t/1.5,1)*np.minimum((dur-t)/1.5,1)
for start in [at('затонул'),at('сутки'),at('вторые')]:
 z=np.maximum(t-start,0);bed+=np.where(t>=start,.015*np.exp(-4*z)*np.sin(2*np.pi*133*z),0)
mix=np.clip(v+bed,-.98,.98)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes((mix*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(p/'mix.wav'),'-vf',f'fps=30,ass={p/"subtitles.ass"}','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-t',str(dur),'-movflags','+faststart',str(p/'SNG_005_Okene_BASE_V3.mp4')],check=True)
print('DONE',flush=True)
