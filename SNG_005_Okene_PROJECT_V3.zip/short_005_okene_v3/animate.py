from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,cv2,subprocess,json,math
p=Path(__file__).parent
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def tx(d,xy,t,size=32,color='#e9f1ee'):
 d.multiline_text(xy,t,font=ImageFont.truetype(font,size),fill=color,anchor='mm',align='center',spacing=10)
base=Image.new('RGB',(1080,1420),'#091b25');d=ImageDraw.Draw(base)
tx(d,(540,90),'ВОЗДУХ ВНУТРИ ПЕРЕВЁРНУТОГО БУКСИРА',33)
tx(d,(540,160),'Как повар мог оставаться над водой',31,'#a5c7d4')
# Inverted hull locator, with keel above the inverted superstructure.
d.polygon([(100,300),(190,245),(780,245),(930,310),(890,350),(150,350)],fill='#547383',outline='#8da5b0',width=4)
d.polygon([(310,350),(310,410),(690,410),(690,350)],fill='#314c5d',outline='#8da5b0',width=3)
d.rectangle((450,350,555,408),outline='#ffcc80',width=5)
d.line((505,415,505,470),fill='#ffcc80',width=3);tx(d,(540,500),'УВЕЛИЧЕННЫЙ РАЗРЕЗ ПОМЕЩЕНИЯ',27,'#ffcc80')
# Three dimensional sectional compartment, front wall removed.
d.polygon([(130,660),(275,560),(930,560),(930,1050),(790,1170),(130,1170)],fill='#263e49',outline='#91a6ae',width=5)
d.polygon([(130,660),(275,560),(930,560),(790,660)],fill='#53646b')
d.polygon([(790,660),(930,560),(930,1050),(790,1170)],fill='#1c303c')
for x in [210,365,520,675]:
 d.polygon([(x,650),(x+135,558),(x+155,558),(x+20,650)],fill='#7b8b8f')
 d.line((x,665,x,1115),fill='#364e58',width=6)
# Dry air wedge in upper compartment, water below.
d.polygon([(138,675),(785,675),(925,580),(925,850),(790,960),(138,960)],fill='#4e4b36')
# Wall-mounted pipe and rivets.
d.line((155,710,740,710),fill='#b6a485',width=9)
for x in range(165,780,60):d.ellipse((x,677,x+5,682),fill='#a9b0aa')
# Makeshift raised support and mattress, symbolic proportions.
d.polygon([(355,1010),(585,1010),(650,955),(420,955)],fill='#92826a',outline='#d0c2a0')
d.polygon([(355,1010),(585,1010),(585,1045),(355,1045)],fill='#6f6558')
d.rectangle((370,1045,390,1135),fill='#5a5144');d.rectangle((560,1045,580,1135),fill='#5a5144')
# Seated adult silhouette: back, head, bent knees and lowered feet.
skin='#b98863';shade='#845e48'
d.ellipse((410,780,468,845),fill=skin);d.polygon([(416,835),(454,837),(480,917),(463,962),(411,951),(402,880)],fill=skin)
d.polygon([(411,949),(470,950),(525,900),(546,918),(510,990),(441,996)],fill='#39434a')
d.line((531,918,555,1012),fill=skin,width=23);d.line((555,1012,602,1018),fill=shade,width=18)
d.line((425,865,474,916),fill=shade,width=18);d.line((474,916,526,915),fill=skin,width=16)
d.ellipse((419,785,463,808),fill='#2b2927')
tx(d,(730,770),'ВОЗДУХ',34,'#ffe0a6');d.line((700,802,600,860),fill='#ffe0a6',width=3)
tx(d,(540,1240),'Голова — над водой. Выход — затоплен.',32)
tx(d,(540,1310),'Условная иллюстрация по описанию выжившего',24,'#9bb2bb')
tx(d,(540,1365),'Не точный план Jascon-4 • глубина около 30 м',23,'#9bb2bb')
def panel(t):
 im=base.copy();layer=Image.new('RGBA',im.size);ld=ImageDraw.Draw(layer)
 # Stable water level: only local ripples; no invented continuous flooding.
 level=978
 pts=[(138+x,level+4*math.sin(x/55+t*1.2)) for x in range(0,651,10)]
 ld.polygon(pts+[(790,1162),(138,1162)],fill=(16,98,129,160));ld.line(pts,fill=(128,213,224,210),width=3)
 for j in range(6):
  x=170+j*100+9*math.sin(t+j);y=1035+(j%3)*35
  ld.arc((x,y,x+65,y+12),0,150,fill=(147,219,226,100),width=2)
 im=Image.alpha_composite(im.convert('RGBA'),layer).convert('RGB');d=ImageDraw.Draw(im);tx(d,(708,1080),'ВОДА',32,'#a6e0ed')
 return np.asarray(im)
words=json.loads((p/'boundaries.json').read_text())
def at(w):return next(x['offset']/1e7 for x in words if x['text'].lower().strip('.,:')==w.lower())
a=at('воздушном');b=at('Прошли');(p/'animation_timing.json').write_text(json.dumps({'start':a,'end':b,'motion':'water ripples only; seated subject and camera fixed'}))
Image.fromarray(panel(1)).save(p/'diagram_review.png')
cap=cv2.VideoCapture(str(p/'SNG_005_Okene_BASE_V3.mp4'));duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p/'SNG_005_Okene_BASE_V3.mp4')]))
cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-i',str(p/'SNG_005_Okene_BASE_V3.mp4'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','copy','-t',str(duration),'-movflags','+faststart',str(p/'SNG_005_Okene_PREVIEW_V3.mp4')]
f=subprocess.Popen(cmd,stdin=subprocess.PIPE);n=0
while True:
 ok,fr=cap.read()
 if not ok:break
 fr=cv2.cvtColor(fr,cv2.COLOR_BGR2RGB);t=n/30
 if a<=t<b:fr[:1420]=panel(t-a)
 f.stdin.write(fr.tobytes());n+=1
cap.release();f.stdin.close();assert f.wait()==0;print('Rendered',n,'frames')
