from pathlib import Path
import json,subprocess,wave,math,unicodedata
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageEnhance
p=Path(__file__).parent
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'voice_concat.txt'),'-ar','48000','-ac','1',str(p/'raw.wav')],check=True)
with wave.open(str(p/'raw.wav')) as w:sr=w.getframerate();a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16)
words=json.loads((p/'boundaries.json').read_text());cuts=[]
for x,y in zip(words,words[1:]):
 end=(x['offset']+x['duration'])/1e7;start=y['offset']/1e7
 if start-end>.9:cuts.append((end+.28,start-.28))
parts=[];pos=0
for x,y in cuts:parts.append(a[pos:round(x*sr)]);pos=round(y*sr)
parts.append(a[pos:]);a=np.concatenate(parts)
for w in words:
 t=w['offset']/1e7;w['start']=t-sum(y-x for x,y in cuts if y<=t);w['end']=w['start']+w['duration']/1e7
 w['text']=unicodedata.normalize('NFC',unicodedata.normalize('NFD',w['text']).replace('\u0301',''))
duration=math.ceil((words[-1]['end']+.35)*30)/30
print('DURATION',duration,flush=True)
if not 55<=duration<=60:raise RuntimeError('Duration gate: adjust substantive script, do not pad')
a=a[:round(duration*sr)];a=np.pad(a,(0,max(0,round(duration*sr)-len(a))))
# restrained original low score with gentle metal/liquid textures, all synthesized
rng=np.random.default_rng(19);t=np.arange(len(a))/sr
score=(np.sin(2*np.pi*52*t)+.4*np.sin(2*np.pi*78*t))*.003
score*=.4+.6*np.sin(np.pi*np.minimum(t/duration,1))**2
rupture=next(w['start'] for w in words if 'разорвало' in w['text'].lower())
casualty=next(w['start'] for w in words if w['text'].lower()=='погиб')
score[t>casualty]*=.4
for when,length,kind in [(0.1,1.4,'creak'),(rupture,.24,'impact'),(rupture+.2,3.0,'liquid')]:
 n=round(length*sr);u=np.arange(n)/sr;noise=rng.normal(0,1,n)
 if kind=='creak':fx=np.sin(2*np.pi*(160*u+35*u*u))*.014*np.sin(np.pi*u/length)**2
 elif kind=='impact':fx=(noise*.025+np.sin(2*np.pi*65*u)*.045)*np.exp(-u*24)
 else:fx=np.convolve(noise,np.ones(90)/90,mode='same')*.016*np.sin(np.pi*u/length)**2
 start=round(when*sr);end=min(len(score),start+n);score[start:end]+=fx[:end-start]
voice=a.astype(float)/32768
mix=np.clip(voice*1.05+score,-.9,.9)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype(np.int16).tobytes())
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def F(n):return ImageFont.truetype(font,n)
recon=Image.open(p/'reconstruction.png').convert('RGB');W,H=recon.size
panels=[recon.crop((0,0,765,429)),recon.crop((770,0,W,429)),recon.crop((0,436,765,H)),recon.crop((770,436,W,H))]
tank=Image.open(p/'North_End_molasses_tank.jpg').convert('RGB');disaster=Image.open(p/'BostonMolassesDisaster.jpg').convert('RGB')
visuals=[panels[0],panels[1],tank,Image.open(p/'map.png').convert('RGB'),panels[0],panels[1],panels[3],panels[2],disaster,disaster.crop((0,300,1800,1900)),disaster.crop((1200,100,3000,1800)),tank,panels[1],tank,disaster]
def at(phrase):
 tokens=phrase.lower().replace('ё','е').split()
 normalized=[w['text'].lower().replace('ё','е').strip('.,!?:;—') for w in words]
 for j in range(len(normalized)-len(tokens)+1):
  if normalized[j:j+len(tokens)]==tokens:return words[j]['start']
 raise ValueError(phrase)
starts=[0,1.7,3.3,8,at('бак протекал'),at('но резервуар'),at('пятнадцатого января'),at('почти девять'),at('поток разрушал'),at('улицы покрыла'),at('погиб двадцать'),at('но самое'),at('краска не'),at('его покрасили'),at('чтобы потёков')]

heads=['ОН ПРОТЕКАЛ…','ЕГО ПРОСТО ПОКРАСИЛИ','БОСТОН • 1919','НОРТ-ЭНД • БОСТОН','ПАТОКА СОЧИЛАСЬ ИЗ ШВОВ','КОРИЧНЕВАЯ КРАСКА','15 ЯНВАРЯ 1919','ПОТОК ПАТОКИ','УЛИЦЫ ПОСЛЕ КАТАСТРОФЫ','РАЗРУШЕННЫЙ РАЙОН','21 ПОГИБШИЙ','ОНИ ЗНАЛИ ОБ УТЕЧКАХ','В ЦВЕТ ПАТОКИ','СКРЫТЬ ПРОБЛЕМУ','СКРЫТЬ ПРОБЛЕМУ\n≠ РЕШИТЬ ЕЁ']
recs={0,1,4,5,6,7,12}
manifest=[]
for i,im in enumerate(visuals):
 bg=Image.new('RGB',(1080,1920),'#131b20');d=ImageDraw.Draw(bg)
 thumb=im.copy();thumb.thumbnail((1000,820),Image.Resampling.LANCZOS)
 if i in [2,11,13]:thumb=im.resize((834,654),Image.Resampling.LANCZOS) # authentic low-res photo contained, not full-screen fabrication
 x=(1080-thumb.width)//2;y=820-thumb.height//2
 bg.paste(thumb,(x,y));d.rectangle((x-2,y-2,x+thumb.width+2,y+thumb.height+2),outline='#d8b66d',width=2)
 title=heads[i];size=56
 while d.textbbox((0,0),title,font=F(size))[2]>950:size-=1
 d.text((540,300),title,font=F(size),fill='#f4ead7',anchor='mm')
 label='РЕКОНСТРУКЦИЯ' if i in recs else ('СОВРЕМЕННАЯ КАРТА • © OPENSTREETMAP CONTRIBUTORS' if i==3 else 'АРХИВНАЯ ФОТОГРАФИЯ')
 d.text((540,1250),label,font=F(26),fill='#d8b66d',anchor='mm')
 path=p/f'card{i:02d}.png';bg.save(path)
 end=starts[i+1] if i+1<len(starts) else duration
 manifest.append(f"file '{path}'\noption framerate 30\nduration {end-starts[i]:.8f}\n")
manifest.append(f"file '{path}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest))
def stamp(t):
 n=round(t*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'
ass='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: S,DejaVu Sans,54,&H00FFFFFF,&H000000FF,&H00101010,&H00101010,-1,0,0,0,100,100,0,0,1,4,1,5,95,160,0,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
groups=[];group=[]
for w in words:
 if group and (len(group)>=3 or w['start']-group[-1]['end']>.25):groups.append(group);group=[]
 group.append(w)
if group:groups.append(group)
for group in groups:
 s=group[0]['start'];e=group[-1]['end'];txt=' '.join(w['text'].upper() for w in group)
 for key in ['ПОКРАСИЛИ','ПРОТЕКАЛ','ПОГИБ','ПАТОКИ','ПАТОКА']:
  txt=txt.replace(key,'{\\c&H70C8F4&}'+key+'{\\c&HFFFFFF&}')
 ass+=f'Dialogue: 0,{stamp(s)},{stamp(e)},S,,0,0,0,,{{\\pos(500,1470)}}{txt}\n'
(p/'subtitles.ass').write_text(ass)
(p/'words.json').write_text(json.dumps(words,ensure_ascii=False))
for name,width,crf in [('SNG_002_Molasses_PREVIEW.mp4',540,27),('SNG_002_Molasses_FINAL.mp4',1080,21)]:
 out=p/name
 subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(p/'mix.wav'),'-vf',f'fps=30,ass={p/"subtitles.ass"},scale={width}:-2','-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf',str(crf),'-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-movflags','+faststart',str(out)],check=True)
 print(name,out.stat().st_size,flush=True)
