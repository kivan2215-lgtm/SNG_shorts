from pathlib import Path
import json,subprocess
import cv2,numpy as np
from PIL import Image
from mechanics import panel
p=Path(__file__).parent;src=p.parent/'short_003_chowchilla_v2'
plan=json.loads((src/'shot_timing.json').read_text());mapping={7:'ladder',9:'trap',10:'weight',11:'trap',13:'trap',15:'roof',17:'mattress',18:'escape',19:'shift',20:'dig'}
segments=[(v['start'],v['end'],mapping[i]) for i,v in enumerate(plan) if i in mapping]
(p/'animation_plan.json').write_text(json.dumps([dict(start=s,end=e,mode=m) for s,e,m in segments],indent=2))
if __name__=='__main__':
 # Preserve the entire already approved AAC stream bit-for-bit.
 cap=cv2.VideoCapture(str(src/'SNG_003_Chowchilla_PREVIEW_V2.mp4'));out=p/'SNG_003_Chowchilla_PREVIEW_V4.mp4'
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-i',str(src/'SNG_003_Chowchilla_PREVIEW_V2.mp4'),'-map','0:v:0','-map','1:a:0','-map_metadata','1','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','copy','-t','58.4','-movflags','+faststart',str(out)]
 ff=subprocess.Popen(cmd,stdin=subprocess.PIPE);n=0;last_rgb=None;active=None;transition=None
 while True:
  ok,frame=cap.read()
  if not ok:break
  rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB);t=n/30
  matched=False
  for s,e,m in segments:
   if s<=t<e:
    matched=True
    if active!=s:
     transition=last_rgb[:1420].copy() if last_rgb is not None else rgb[:1420].copy();active=s
    newpanel=panel(m,t-s);alpha=min(1,(t-s)/.18)
    rgb[:1420]=newpanel
    if alpha<1:rgb[410:1110]=np.asarray(Image.blend(Image.fromarray(transition[410:1110]),Image.fromarray(newpanel[410:1110]),alpha))
    break
  if not matched:active=None
  last_rgb=rgb.copy()
  ff.stdin.write(rgb.tobytes());n+=1
  if n%300==0:print('Frame',n,flush=True)
 cap.release();ff.stdin.close();assert ff.wait()==0
 assert n==1752,n
 print('Written',out.name,out.stat().st_size,flush=True)
