from pathlib import Path
import subprocess,json,hashlib,re
p=Path(__file__).parent;src=p.parent/'short_003_chowchilla_v2';v=p/'SNG_003_Chowchilla_PREVIEW_V4.mp4'
x=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,pix_fmt,r_frame_rate,sample_rate,channels,nb_frames:format=duration,size','-of','json',str(v)]))
assert x['streams'][0]['nb_frames']=='1752' and x['format']['duration']=='58.400000'
assert x['streams'][0]['width']==1080 and x['streams'][0]['height']==1920 and x['streams'][0]['r_frame_rate']=='30/1'
assert x['streams'][0]['codec_name']=='h264' and x['streams'][0]['pix_fmt']=='yuv420p'
assert x['streams'][1]['codec_name']=='aac' and x['streams'][1]['sample_rate']=='48000' and x['streams'][1]['channels']==2
hashes=[]
for f in [src/'SNG_003_Chowchilla_PREVIEW_V2.mp4',v]:
 h=subprocess.check_output(['ffmpeg','-v','error','-i',str(f),'-map','0:a:0','-c','copy','-f','hash','-hash','sha256','-']).decode().strip();hashes.append(h)
assert hashes[0]==hashes[1],'Approved audio stream changed'
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-vf','blackdetect=d=0.1:pix_th=0.025:pic_th=0.98','-f','null','-'],capture_output=True,text=True)
assert r.returncode==0 and 'black_start:' not in r.stderr
report={'media':x,'full_decode_ok':True,'no_black_intervals':True,'approved_V2_AAC_bit_identical':True,'audio_sha256':hashes[0],'subtitle_cues_and_timing_retained':True,'only_explanatory_diagram_region_replaced':True,'motion':'functional closeups: removing ladder, weight pressure, building mattress stack, lifting and propping lid, shifting barrier and clearing soil','camera_fixed':True,'mesh_not_to_scale':True,'mp4_sha256':hashlib.sha256(v.read_bytes()).hexdigest()}
(p/'qc_preview_v4.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
