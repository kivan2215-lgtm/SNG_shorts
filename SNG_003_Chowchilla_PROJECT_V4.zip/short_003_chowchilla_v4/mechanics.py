from pathlib import Path
from functools import lru_cache
from PIL import Image,ImageDraw,ImageFont
import math,json,numpy as np
p=Path(__file__).parent;assets=p.parent/'short_003_chowchilla_v3'
GOLD='#ffcf7d';BLUE='#88d6e6';WHITE='#f2f1e9';RED='#ef9b7d';MUTED='#9cb1be'
@lru_cache(maxsize=80)
def F(n):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',n)
def text(d,xy,t,n=32,c=WHITE,w=950):
 while max(F(n).getlength(s) for s in t.split('\n'))>w:n-=1
 d.multiline_text(xy,t,font=F(n),fill=c,anchor='mm',align='center',spacing=9)
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
def arrow(d,a,b,color=GOLD,width=6):
 d.line((*a,*b),fill=color,width=width);ang=math.atan2(b[1]-a[1],b[0]-a[0]);d.polygon([b,(b[0]-18*math.cos(ang-.5),b[1]-18*math.sin(ang-.5)),(b[0]-18*math.cos(ang+.5),b[1]-18*math.sin(ang+.5))],fill=color)
def box3(d,x,y,w,h,front,top='#b3c9ce',side='#405f6f',depth=10):
 d.polygon([(x,y),(x+depth,y-depth),(x+w+depth,y-depth),(x+w,y)],fill=top)
 d.polygon([(x+w,y),(x+w+depth,y-depth),(x+w+depth,y+h-depth),(x+w,y+h)],fill=side)
 d.rounded_rectangle((x,y,x+w,y+h),radius=4,fill=front,outline='#74939f',width=2)
imgs={k:Image.open(assets/(k+'.png')).convert('RGBA') for k in ['ladder','trap','weight','roof','mattress','escape','dig']}
# Keep the load present while the mattresses are being stacked.
weighted_mattress=imgs['mattress'].copy();region=(500,235,765,410);weighted_mattress.paste(imgs['weight'].crop(region),(region[0],region[1]))
imgs['mattress']=weighted_mattress
motion=[imgs['mattress']]+[Image.open(assets/f'lid_motion_{i:02d}.png').convert('RGBA') for i in range(1,10)]+[imgs['escape']]
info={
 'ladder':('Вход был только сверху','ЛЕСТНИЦА → КУЗОВ','Спуск через люк','Лестница внутри'),
 'trap':('Путь обратно перекрыли','ЛЕСТНИЦУ УБРАЛИ, ВЫХОД ЗАКРЫЛИ','Снаружи — преграда','Внутри — 27 человек'),
 'weight':('Что удерживало крышку','НАГРУЗКА СВЕРХУ','Два аккумулятора','Металлический лист'),
 'roof':('Внутри становилось опаснее','КРЫША НАЧАЛА ПРОГИБАТЬСЯ','Кузов под землёй','Металл деформировался'),
 'mattress':('Матрасы заменили лестницу','ДОБРАТЬСЯ ДО ЛЮКА','Нужна высота','Стопка матрасов'),
 'escape':('Поднять — и удержать','КРЫШКУ ПРИПОДНЯЛИ И ПОДПЕРЛИ','Поднять крышку','Подпереть деревом'),
 'shift':('Сдвинуть тяжёлую преграду','ОСВОБОДИТЬ МЕСТО НАД ЛЮКОМ','Сдвинуть лист и груз','Проход над крышкой'),
 'dig':('Последняя преграда — земля','РАЗГРЕСТИ ВЫХОД РУКАМИ','Земля над люком','Расчистить проход')}
@lru_cache(maxsize=9)
def base(mode):
 im=Image.new('RGB',(1080,1420));d=ImageDraw.Draw(im)
 for y in range(1420):
  v=max(0,int(10*(1-abs(y-760)/900)));d.line((0,y,1080,y),fill=(10+v,20+v,29+v))
 text(d,(540,62),'СХЕМА ДЕЙСТВИЙ • ЧОУЧИЛЛА, 1976',25,BLUE)
 text(d,(540,139),info[mode][0],51)
 d.line((65,200,1015,200),fill='#405767',width=2)
 # Context model at left, two clear functional labels at right.
 d.rounded_rectangle((735,320,1020,435),radius=18,fill='#152c3a',outline='#385768',width=2)
 d.rounded_rectangle((735,485,1020,600),radius=18,fill='#152c3a',outline='#385768',width=2)
 def wrap(t):
  words=t.split();lines=[];line=[]
  for word in words:
   if line and F(29).getlength(' '.join(line+[word]))>240:lines.append(' '.join(line));line=[]
   line.append(word)
  if line:lines.append(' '.join(line))
  return '\n'.join(lines)
 text(d,(877,377),wrap(info[mode][2]),29,BLUE,w=250)
 text(d,(877,542),wrap(info[mode][3]),29,GOLD,w=250)
 text(d,(540,805),info[mode][1],32,GOLD)
 # A large functional closeup under the context view.
 d.rounded_rectangle((55,850,1025,1275),radius=24,fill='#122936',outline='#4b7183',width=2)
 text(d,(540,889),'ДЕТАЛЬНО: ЧТО ПРОИСХОДИТ',23,BLUE)
 if mode in ['mattress','escape','shift','dig']:
  active=['mattress','escape','shift','dig'].index(mode)
  for i,tx in enumerate(['ПОДЪЁМ','ПОДПОРКА','СДВИГ','ЗЕМЛЯ']):
   x=55+i*248;d.rounded_rectangle((x,1312,x+228,1365),radius=14,fill='#38514e' if i<=active else '#142834',outline=GOLD if i==active else '#38535f',width=2);text(d,(x+114,1338),str(i+1)+' '+tx,24,GOLD if i==active else MUTED,w=215)
 text(d,(540,1400),'ПОЯСНЯЮЩАЯ 3D-СХЕМА • УСЛОВНЫЕ РАЗМЕРЫ',21,MUTED)
 return im

def detailed(d,mode,t):
 # Local side section: labels on left, action on right; no assumed exact geometry.
 left=580;right=855;top=1022
 d.rounded_rectangle((520,970,948,1225),radius=12,fill='#0a1c26',outline='#3b6478',width=3)
 # Short shaft, corrugated wall edges, steel lid.
 for x in [540,914]:
  d.rectangle((x,1000,x+15,1218),fill='#4f7989')
  for y in range(1025,1218,26):d.line((x-2,y,x+17,y),fill='#8cabb6',width=2)
 lidy=top
 if mode in ['escape','shift','dig']:
  q=ease(t/.75) if mode=='escape' else 1
  d.polygon([(561,top),(883,top-49*q),(890,top-30*q),(568,top+19)],fill='#c5d8dd',outline='#e6f1f3')
  if q>.55:
   prop=ease((t-.42)/.45) if mode=='escape' else 1
   x=882-75*prop;d.polygon([(x,top-6),(x+18,top-6),(x+18,top-43),(x+8,top-43)],fill='#b98e59',outline=GOLD)
 else:box3(d,561,lidy,322,18,'#9bb4bf',depth=8)
 if mode in ['trap','weight','shift']:
  # The steel sheet and its two weights move together when the barrier is shifted.
  shift=100*ease(t/.9) if mode=='shift' else 0
  compress=ease(t/.9) if mode=='weight' else 1
  lift=46*(1-compress)
  sy=top-20-lift
  box3(d,552+shift,sy,342,12,'#b2c1c7',depth=7)
  for x in [585,748]:
   box3(d,x+shift,sy-75,118,68,'#213d4c',top='#5d7c8b',side='#102a38',depth=10)
   d.rectangle((x+14+shift,sy-85,x+33+shift,sy-75),fill='#d5e1e1');d.rectangle((x+81+shift,sy-85,x+99+shift,sy-75),fill='#d5e1e1')
   d.line((x+18+shift,sy-32,x+97+shift,sy-32),fill=GOLD,width=7)
  if mode=='weight':
   arrow(d,(640,1070),(640,1152),RED);arrow(d,(813,1070),(813,1152),RED)
   text(d,(278,1002),'ДВА АККУМУЛЯТОРА',27,GOLD,w=400);text(d,(278,1070),'ЛИСТ ПРИЖИМАЕТ\nКРЫШКУ СВЕРХУ',31,w=410)
   text(d,(740,1188),'ГРУЗ ДАВИТ НА КРЫШКУ',22,RED,w=400)
  elif mode=='shift':
   arrow(d,(620,1138),(870,1138),GOLD);text(d,(280,1010),'УБРАТЬ ПРЕГРАДУ',31,GOLD,w=410);text(d,(280,1100),'СДВИНУТЬ ЛИСТ\nИ АККУМУЛЯТОРЫ',29,w=410)
  else:
   text(d,(280,1015),'ПРОХОД ЗАКРЫТ',33,RED,w=410);text(d,(280,1100),'ЛЕСТНИЦУ\nУБРАЛИ НАВЕРХ',29,w=410)
   q=ease(t/.7)
   for x in [660,805]:d.line((x,1190-210*q,x,1060-210*q),fill='#7e6a52',width=7)
   for y in range(1080,1190,30):d.line((660,y-210*q,805,y-210*q),fill='#7e6a52',width=6)
 if mode=='ladder':
  for x in [640,805]:d.line((x,980,x,1200),fill='#b49a71',width=7)
  for y in range(1000,1200,29):d.line((640,y,805,y),fill='#b49a71',width=7)
  text(d,(280,1010),'ЛЮК НАД ГОЛОВОЙ',31,GOLD,w=410);text(d,(280,1100),'ЧЕРЕЗ ЛЕСТНИЦУ\nВНИЗ, В КУЗОВ',29,w=410)
  y=1000+(t%1.2)/1.2*160;arrow(d,(880,y-45),(880,y),BLUE)
 if mode=='mattress':
  count=1+min(5,int(t/.22));target=1048
  d.line((535,target,920,target),fill='#557b8b',width=2)
  for j in range(count):box3(d,607,1198-j*28,240,23,'#9d8a70' if j%2==0 else '#628995',top='#d0c5aa',side='#344d58',depth=7)
  arrow(d,(890,1190),(890,target+9),GOLD)
  text(d,(278,1015),'НУЖНО ДОСТАТЬ\nДО КРЫШКИ',31,GOLD,w=410);text(d,(278,1120),'МАТРАСЫ СКЛАДЫВАЮТ\nДРУГ НА ДРУГА',28,w=410)
 if mode=='escape':
  first=t<.9
  text(d,(278,1005),'СНАЧАЛА ПОДНЯТЬ' if first else 'ЗАТЕМ ПОДПЕРЕТЬ',31,GOLD,w=410)
  text(d,(278,1100),'УСИЛИЕ СНИЗУ' if first else 'ДЕРЕВО УДЕРЖИВАЕТ\nОБРАЗОВАВШИЙСЯ ЗАЗОР',28,w=410)
  arrow(d,(735,1175),(735,1062),GOLD)
  if t>.9:arrow(d,(890,1140),(830,1035),BLUE)
 if mode=='dig':
  q=ease(t/1.35)
  for j in range(55):
   x=565+(j*47)%310;y=969+(j*23)%43;direction=-1 if j%2 else 1
   x+=direction*q*(65+(j%8)*8);y-=q*(40+(j%5)*8)
   if abs(x-725)>145 or q<.82:
    r=max(1,8*(1-q*.6));d.ellipse((x-r,y-r,x+r,y+r),fill='#94744f',outline='#c7a87b')
  arrow(d,(710,1110),(600,1045),BLUE);arrow(d,(760,1110),(875,1045),BLUE)
  text(d,(278,1015),'ОСТАЛАСЬ ЗЕМЛЯ',31,GOLD,w=410);text(d,(278,1110),'РАЗГРЕБАЮТ РУКАМИ\nИЗНУТРИ НАРУЖУ',29,w=410)
 if mode=='roof':
  d.rectangle((550,947,925,995),fill='#5a4836')
  sag=25*ease(t/1.15);pts=[]
  for j in range(31):x=550+j*12.5;pts.append((x,1020+sag*math.sin(math.pi*j/30)))
  d.line(pts,fill='#b2c6cf',width=14);d.line([(x,y+9) for x,y in pts],fill=RED,width=3)
  arrow(d,(735,1090),(735,1155),RED)
  text(d,(278,1005),'КРЫША ДЕФОРМИРУЕТСЯ',30,RED,w=410);text(d,(278,1100),'ПРОСТРАНСТВО ВНУТРИ\nСТАНОВИТСЯ ОПАСНЕЕ',28,w=410)

@lru_cache(maxsize=12)
def context(k):return imgs[k].resize((700,700),Image.Resampling.LANCZOS)
def panel(mode,t):
 im=base(mode).copy();key='escape' if mode=='shift' else mode;obj=context(key)
 if mode=='escape':
  z=min(10,max(0,t/.9*10));i=min(9,int(z));obj=Image.blend(motion[i],motion[i+1],z-i).resize((700,700),Image.Resampling.LANCZOS)
 if mode=='mattress':obj=context('mattress')
 if mode=='shift':obj=Image.blend(context('weight'),context('escape'),ease(t/1.0))
 im.paste(obj,(-5,140),obj);d=ImageDraw.Draw(im)
 # Mode-specific pin highlights retain the full 3D spatial context.
 coords=json.loads((assets/'anchors.json').read_text());anchors={k:(-5+round(v[0]*700),140+round((1-v[1])*700)) for k,v in coords.items()}
 a,b= {'weight':('weight','lid'),'mattress':('lid','mattress'),'escape':('lid','wedge'),'shift':('weight','lid'),'dig':('lid','mattress'),'roof':('trailer','roof'),'ladder':('lid','trailer'),'trap':('lid','trailer')}[mode]
 for key,y,c in [(a,377,BLUE),(b,542,GOLD)]:
  pt=anchors[key];d.line((*pt,710,y,735,y),fill=c,width=3);r=6;d.ellipse((pt[0]-r,pt[1]-r,pt[0]+r,pt[1]+r),outline=c,width=3)
 detailed(d,mode,t)
 return np.asarray(im)
