import bpy,math,json,os
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
p=Path(__file__).parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=False
s.render.resolution_x=1000;s.render.resolution_y=1000;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.film_transparent=True
s.world.color=(.16,.2,.25);s.view_settings.view_transform='AgX'
def mat(name,color,metal=0,rough=.5):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=rough;return m
steel=mat('Blue steel',(.12,.29,.34),.65,.32);silver=mat('Sheet metal',(.51,.61,.64),.8,.25);dark=mat('Battery casings',(.025,.05,.06),.25);amber=mat('Warm amber',(.9,.52,.13),.1);cream=mat('Mattress fabric',(.66,.52,.37));edge=mat('Piping fabric',(.86,.75,.58));wood=mat('Timber wedge',(.40,.21,.08));earth=mat('Cut earth',(.24,.12,.055));sand=mat('Sand surface',(.42,.27,.12));black=mat('Hatch void',(.007,.013,.02));foam=mat('Mattress alternate fabric',(.22,.38,.43))
# Fine real material grain, not a flat generic diagram.
for m,scale,strength in [(earth,7,.25),(sand,18,.15),(cream,100,.08),(foam,100,.08)]:
 nt=m.node_tree;n=nt.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=scale;b=nt.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=strength;b.inputs['Distance'].default_value=.12;nt.links.new(n.outputs['Fac'],b.inputs['Height']);nt.links.new(b.outputs['Normal'],nt.nodes.get('Principled BSDF').inputs['Normal'])
nt=earth.node_tree;noise=next(n for n in nt.nodes if n.type=='TEX_NOISE');ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(.10,.048,.019,1);ramp.color_ramp.elements[1].color=(.34,.20,.095,1);nt.links.new(noise.outputs['Fac'],ramp.inputs[0]);nt.links.new(ramp.outputs['Color'],nt.nodes.get('Principled BSDF').inputs['Base Color'])
def cube(name,loc,size,m,bevel=.035):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if bevel:
  mod=o.modifiers.new('Soft manufactured edges','BEVEL');mod.width=bevel;mod.segments=3;o.modifiers.new('Normals','WEIGHTED_NORMAL')
 return o
cube('Earth pedestal',(0,0,-.35),(9,5,.65),earth,.12)
cube('Earth back cut',(0,2.1,1.85),(9,.75,4.1),earth,.07)
cube('Ground top back',(0,2.12,3.98),(9,.84,.18),sand,.04)
cube('Earth left cut',(-4.22,.3,1.85),(.55,3.5,4.1),earth,.06)
cube('Ground top left',(-4.22,.3,3.98),(.65,3.5,.18),sand,.04)
cube('Trailer floor',(0,0,.08),(7.8,2.95,.18),steel)
cube('Trailer back',(0,1.45,1.5),(7.8,.12,2.9),steel)
cube('Trailer end',(3.85,0,1.5),(.12,2.95,2.9),steel)
for x in [i*.28-3.6 for i in range(27)]:cube('Corrugated rear rib',(x,1.34,1.55),(.055,.08,2.65),silver,.012)
for y in [i*.25-1.2 for i in range(11)]:cube('Corrugated end rib',(3.77,y,1.55),(.07,.045,2.65),silver,.01)
# Partial roof leaves the front and centre open for explanation; shaft is the only exit.
cube('Roof section over hatch',(2.45,.45,3.02),(2.9,1.9,.12),steel)
shaft=[]
for loc,size in [((1.6,1.0,3.6),(1.3,.10,1.15)),((2.25,.4,3.6),(.10,1.3,1.15)),((.95,.4,3.6),(.10,1.3,1.15))]:shaft.append(cube('Access shaft wall',loc,size,steel))
cube('Dark opening',(1.6,.4,3.05),(1.2,1.2,.03),black)
# Cover rotates about its rear hinge; animations render separate deterministic states.
bpy.ops.object.empty_add(location=(1.6,1.02,4.21));hinge=bpy.context.object;hinge.name='Hatch hinge'
lid=cube('Hatch cover',(1.6,.4,4.2),(1.4,1.4,.10),silver);lid.parent=hinge;lid.matrix_parent_inverse=hinge.matrix_world.inverted()
weight=[]
weight.append(cube('Extra steel sheet',(1.6,.4,4.30),(1.75,1.65,.07),silver))
for x in [1.17,2.02]:
 weight.append(cube('45kg battery',(x,.4,4.68),(.65,.95,.69),dark,.065))
 for y in [.12,.68]:weight.append(cube('Battery terminals',(x,y,5.07),(.12,.1,.12),silver,.02))
 weight.append(cube('Battery amber band',(x,-.082,4.68),(.49,.012,.13),amber,.01))
ladder=[]
for x in [1.2,1.98]:ladder.append(cube('Ladder rail',(x,.15,1.95),(.065,.08,3.6),wood,.015))
for z in [i*.30+.25 for i in range(12)]:ladder.append(cube('Ladder rung',(1.59,.15,z),(.8,.09,.065),wood,.012))
matt=[]
for j in range(7):
 z=.3+j*.31
 o=cube('Mattress',(1.55,-.05,z),(2.4,1.62,.29),cream if j%2==0 else foam,.13);matt.append(o)
 matt.append(cube('Mattress piping',(1.55,-.866,z),(2.14,.018,.032),edge,.01))
 for x in [1.0,1.55,2.1]:
  matt.append(cube('Fabric tuft',(x,-.875,z+.04),(.04,.012,.04),edge,.018))
wedge=cube('Wood prop',(2.08,.0,4.32),(.12,.12,.48),wood,.02)
# Show the collapsing ceiling only as a highlight and modest bend in a separate state.
roofalert=cube('Roof deflection strip',(-1,1.25,2.95),(3.7,.14,.1),amber,.03)
for name,loc,power,size,col in [('Key',(0,-6,10),1800,8,(1,.84,.65)),('Rim',(4,4,8),2200,6,(.45,.72,1)),('Fill',(-6,-2,4),900,5,(.65,.82,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=col;o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(9,-13,10));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,2.0))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=12.0;s.camera=cam
bpy.context.view_layer.update()
anchors={k:list(world_to_camera_view(s,cam,Vector(v))) for k,v in {'lid':(1.6,.4,4.2),'weight':(1.6,.4,4.9),'mattress':(1.55,-.5,1.5),'wedge':(2.08,.0,4.32),'ladder':(1.6,.15,1.6),'trailer':(-1,-1.0,1.0),'ground':(-3,2,4),'roof':(-1,1.25,2.95)}.items()};(p/'anchors.json').write_text(json.dumps(anchors,indent=2))
def visible(objs,yes):
 for o in objs:o.hide_render=not yes
states=['ladder','trap','weight','roof','mattress','escape','dig']
if os.environ.get('TEST_MODEL'):states=['weight']
for mode in states:
 visible(ladder,mode=='ladder');visible(weight,mode in ['trap','weight','roof']);visible(matt,mode in ['mattress','escape','dig']);wedge.hide_render=mode not in ['escape','dig'];roofalert.hide_render=mode!='roof';lid.hide_render=mode=='ladder';hinge.rotation_euler.x=math.radians(-23 if mode in ['escape','dig'] else 0)
 s.render.filepath=str(p/(mode+'.png'));bpy.ops.render.render(write_still=True)
# Deterministic opening motion frames. The steel cover visibly pivots upward.
if not os.environ.get('TEST_MODEL'):
 visible(weight,False);visible(matt,True);visible(ladder,False);roofalert.hide_render=True;lid.hide_render=False;wedge.hide_render=True
 for i in range(1,10):
  hinge.rotation_euler.x=math.radians(-23*i/10);s.render.filepath=str(p/f'lid_motion_{i:02d}.png');bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(p/'Chowchilla_explanatory_model.blend'))
