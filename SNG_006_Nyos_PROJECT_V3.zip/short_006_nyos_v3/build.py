from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
import numpy as np,subprocess,json,math,wave,re,shutil
p=Path(__file__).parent;voice=p/'v0.mp3'
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(voice),'-af','silencedetect=noise=-40dB:d=0.55','-f','null','-'],capture_output=True,text=True)
a=list(map(float,re.findall('silence_start: ([0-9.]+)',r.stderr)));b=list(map(float,re.findall('silence_end: ([0-9.]+)',r.stderr)));cuts=[(x+.22,y-.22) for x,y in zip(a,b) if y-x>.65]
subprocess.run(['ffmpeg','-y','-v','error','-i',str(voice),'-ar','48000','-ac','1',str(p/'original.wav')],check=True)
with wave.open(str(p/'original.wav')) as w:v=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2')
parts=[];last=0
for x,y in cuts:parts.append(v[last:round(x*48000)]);last=round(y*48000)
parts.append(v[last:]);v=np.concatenate(parts)
with wave.open(str(p/'voice.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes(v.tobytes())
def remap(t):return t-sum(max(0,min(t,y)-x) for x,y in cuts if t>x)
words=json.loads((p/'boundaries.json').read_text());
for w in words:w['offset']=round(remap(w['offset']/1e7)*1e7)
duration=math.ceil(len(v)/1600)/30
(p/'edited_boundaries.json').write_text(json.dumps(words,ensure_ascii=False))
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def txt(d,xy,s,n=45,color='#f5f0e6',width=940):
 while max(ImageFont.truetype(font,n).getlength(x) for x in s.split('\n'))>width:n-=1
 d.multiline_text(xy,s,font=ImageFont.truetype(font,n),anchor='mm',align='center',fill=color,spacing=15)
def canvas(title):
 im=Image.new('RGB',(1080,1920),'#0b2029');d=ImageDraw.Draw(im);txt(d,(540,140),title,47);return im,d
grid=Image.open(p/'recon.png').convert('RGB');W,H=grid.size
panels=[grid.crop((c*W//3+4,r*H//3+4,(c+1)*W//3-4,(r+1)*H//3-4)) for r in range(3) for c in range(3)]
def scene(i,title):
 im,d=canvas(title);pic=ImageOps.fit(panels[i],(1080,1080),Image.Resampling.LANCZOS);im.paste(pic,(0,255));return im
def archive(file,title,credit):
 im,d=canvas(title);pic=ImageOps.exif_transpose(Image.open(p/file).convert('RGB'));pic.thumbnail((1020,1070),Image.Resampling.LANCZOS);im.paste(pic,((1080-pic.width)//2,800-pic.height//2));return im

def chart(stage):
 pic=Image.open(p/'cutaway.png').convert('RGB');im=ImageOps.fit(pic,(1080,1920),Image.Resampling.LANCZOS)
 # The original scene is an illustrative landform, not an actual bathymetric profile.
 d=ImageDraw.Draw(im,'RGBA');d.rounded_rectangle((35,42,1045,225),radius=28,fill=(7,25,34,205));d.rounded_rectangle((35,1500,1045,1830),radius=28,fill=(7,25,34,210))
 labels=['1  CO₂ НАКАПЛИВАЛСЯ В ГЛУБИНЕ','2  ГАЗ ВЫРВАЛСЯ ИЗ ВОДЫ','3  НЕВИДИМЫЙ ГАЗ ПОШЁЛ В ДОЛИНЫ']
 txt(d,(540,102),'ОЗЕРО НИОС: ПОЧЕМУ ПОГИБЛИ ЛЮДИ',33)
 txt(d,(540,170),labels[stage],31,'#ffd28a')
 # First reveal dissolved gas; then ascent; then the schematic downslope route.
 for j in range(11):
  x=260+(j%4)*155;y=1130+(j//4)*100
  d.ellipse((x,y,x+15,y+15),fill=(240,210,144,220))
 if stage>=1:
  d.line((520,1150,520,650),fill=(255,210,138,230),width=12);d.polygon([(520,620),(493,670),(547,670)],fill=(255,210,138,230))
 if stage>=2:
  d.line((660,570,830,690,1000,980),fill=(255,210,138,245),width=11,joint='curve');d.polygon([(1010,1000),(970,975),(1000,950)],fill=(255,210,138,245))
 txt(d,(540,1570),'ГАЗ НЕВИДИМ: ЖЁЛТЫЕ ЛИНИИ ПОКАЗЫВАЮТ НАПРАВЛЕНИЕ',27)
 txt(d,(540,1650),'В ГЛУБИНЕ — НАКОПЛЕНИЕ  •  НА СКЛОНАХ — СТОК',28,'#c9e0e2')
 txt(d,(540,1770),'ХУДОЖЕСТВЕННЫЙ РАЗРЕЗ • НЕ ТОЧНАЯ КАРТА',23,'#b3c8c9')
 return im

def pipes():
 im=ImageOps.fit(Image.open(p/'cutaway.png').convert('RGB'),(1080,1920),Image.Resampling.LANCZOS);d=ImageDraw.Draw(im,'RGBA')
 d.rounded_rectangle((45,60,1035,250),radius=25,fill=(7,24,31,210))
 txt(d,(540,130),'ПОСЛЕ КАТАСТРОФЫ: ДЕГАЗАЦИЯ',35)
 d.line((500,1380,500,600),fill=(225,231,226,245),width=28)
 d.line((500,1380,500,600),fill=(65,95,100,235),width=14)
 d.ellipse((480,1375,520,1395),fill=(248,204,117,255))
 d.rounded_rectangle((405,585,595,610),radius=8,fill=(202,175,113,255),outline=(245,220,166,255),width=3)
 for x in [422,556]:d.ellipse((x,605,x+40,635),fill=(210,195,144,255))
 for x in [450,480,520]:d.arc((x,470,x+42,580),200,340,fill=(232,242,233,210),width=4)
 txt(d,(720,690),'ПЛАВУЧАЯ ОПОРА',22,'#f5d193')
 d.line((630,710,545,610),fill=(242,214,166,240),width=3)
 d.polygon([(500,530),(475,590),(525,590)],fill=(246,216,155,245))
 d.rounded_rectangle((60,1480,1020,1810),radius=22,fill=(7,24,31,215))
 txt(d,(540,1530),'ТРУБА ЗАБИРАЕТ ВОДУ С ГЛУБИНЫ',29,'#f5d193')
 txt(d,(540,1620),'CO₂ ВЫХОДИТ НА ПОВЕРХНОСТИ',29,'#f5d193')
 txt(d,(540,1745),'УСТАНОВЛЕНА ПОЗЖЕ • УСЛОВНАЯ СХЕМА',23,'#b5cbd0')
 return im
scenes=[
 (0,scene(0,'УТРО ПОСЛЕ КАТАСТРОФЫ')),(3,scene(1,'ДОМА СТОЯЛИ ЦЕЛЫМИ')),
 (6,scene(8,'НИ ПОЖАРА, НИ СЛЕДОВ НАПАДЕНИЯ')),(9,scene(2,'РАСТЕНИЯ ОСТАЛИСЬ НЕВРЕДИМЫ')),
 (12,archive('archive0.jpg','ОЗЕРО НИОС • 1986','')),
 (15,scene(4,'ГРОХОТ СО СТОРОНЫ ОЗЕРА')),(18,scene(5,'НОЧЬ. БЛИЗЛЕЖАЩИЕ ДЕРЕВНИ')),
 (21,scene(0,'ЛЮДИ ТЕРЯЛИ СОЗНАНИЕ')),(24,scene(1,'НЕКОТОРЫЕ ОЧНУЛИСЬ ПОЗЖЕ')),
 (27,archive('archive3.jpg','ПОСЛЕ КАТАСТРОФЫ','')),
 (30,scene(8,'ПОСТРАДАЛО НЕСКОЛЬКО ПОСЕЛЕНИЙ')),(33,scene(2,'БОЛЕЕ 1700 ПОГИБШИХ')),
 (36,archive('nyos_smithsonian.jpg','ОЗЕРО НИОС • ИСТОРИЧЕСКОЕ ФОТО','')),
 (39,archive('archive1.jpg','ОЗЕРО НИОС • 1992','')),
 (42,chart(0)),(47,chart(1)),(52,chart(2)),(55.5,pipes()),
 (58,archive('archive2.jpg','ТРУБЫ ДЕГАЗАЦИИ • 2001','')),
 (60.5,archive('archive4.jpg','ОЗЕРО НИОС • 2006',''))]

# Shift last cards to exact duration if needed, keep reveal near 40 seconds.
scenes=[(min(t,duration-.6),im) for t,im in scenes if t<duration-.5];scenes.sort(key=lambda x:x[0])
manifest=[]
for i,(t,im) in enumerate(scenes):
 end=scenes[i+1][0] if i+1<len(scenes) else duration;f=p/f'card{i:02}.png';im.save(f);manifest.append(f"file '{f}'\noption framerate 30\nduration {end-t:.6f}\n")
manifest.append(f"file '{f}'\noption framerate 30\n");(p/'video.txt').write_text(''.join(manifest))
header=(p.parent/'short_004_juliane_v2/subtitles.ass').read_text().split('Dialogue:')[0]
def ts(t):return f'{int(t//3600)}:{int(t//60)%60:02}:{t%60:05.2f}'
lines=[]
for i in range(0,len(words),4):
 g=words[i:i+4];a=g[0]['offset']/1e7;b=words[i+4]['offset']/1e7 if i+4<len(words) else duration
 label=' '.join(x['text'].upper() for x in g[:2])+'\\N'+' '.join(x['text'].upper() for x in g[2:]);lines.append(f'Dialogue: 0,{ts(a)},{ts(b)},S,,0,0,0,,{{\\pos(500,1510)}}{label}\n')
(p/'subtitles.ass').write_text(header+''.join(lines))
# Quiet original minor-key ambience, starting in silence and fading out in final second.
t=np.arange(len(v))/48000;music=.010*np.sin(2*np.pi*47*t)+.005*np.sin(2*np.pi*70.5*t)+.003*np.sin(2*np.pi*94*t)*((.5+.5*np.sin(2*np.pi*.6*t))**4);music*=np.minimum(np.maximum((t-2)/3,0),1)*np.minimum(np.maximum((duration-t)/1,0),1)
mix=np.clip(v.astype(float)/32768+music,-1,1)
with wave.open(str(p/'mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(48000);w.writeframes((mix*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(p/'video.txt'),'-i',str(p/'mix.wav'),'-vf',f'fps=30,ass={p/"subtitles.ass"}','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-ac','2','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-t',str(duration),'-movflags','+faststart',str(p/'SNG_006_Nyos_PREVIEW.mp4')],check=True)
print('DURATION',duration,'SCENES',len(scenes))
